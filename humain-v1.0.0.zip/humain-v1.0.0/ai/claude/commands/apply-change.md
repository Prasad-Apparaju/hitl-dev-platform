---
description: Analyze and plan a change before writing code — produces impact analysis, documentation plan, test plan, and initializes the HumAIn context file
argument-hint: "[issue number] [change description]"
---

Invoke the `apply-change` skill with $ARGUMENTS.

Do not write any code until this skill has completed and you have confirmed the HumAIn context file (.humain/current-change.yaml) is initialized.
