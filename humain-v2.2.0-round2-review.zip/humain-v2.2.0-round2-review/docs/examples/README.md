# examples/

**Worked examples** — see the HumAIn process applied to specific project types.

| Example | What it shows |
|---------|--------------|
| `greenfield/` | A new project set up from scratch with `/humain:dev-start-from-prd` — PRD, manifest, first decision packet, and initial slice |

Examples are read-only reference material. They are not connected to any live system.
