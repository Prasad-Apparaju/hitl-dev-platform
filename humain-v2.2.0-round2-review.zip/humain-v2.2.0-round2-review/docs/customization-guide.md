# Customization Guide

How to find and edit skills, agents, hooks, and templates — for both Claude Code and Codex users.

## Where platform files live

All skills, agents, and hooks live inside the platform repo. If you followed the recommended setup, that is `~/tools/humain`. Open that directory, find the file, edit it, save. Changes take effect on the next Claude Code or Codex session — no rebuild or restart needed.

```
~/tools/humain/
  ai/claude/          ← slash command prompts
  agents/          ← subagent role definitions
  hooks/           ← enforcement scripts (Claude Code)
  ai/codex/           ← Codex-specific files
  ai/shared/templates/       ← document templates used by skills
```

---

## Skills — Claude Code slash commands

| Slash command | File to edit |
|---|---|
| `/humain:dev-start-from-prd` | `ai/claude/start-from-prd/SKILL.md` |
| `/humain:dev-start-brownfield` | `ai/claude/start-brownfield/SKILL.md` |
| `/humain:dev-start-migration` | `ai/claude/start-migration/SKILL.md` |
| `/humain:dev-practices` | `ai/claude/dev-practices/SKILL.md` |
| `/humain:apply-change` | `ai/claude/apply-change/SKILL.md` |
| `/humain:check-conventions` | `ai/claude/check-conventions/SKILL.md` |
| `/humain:impact-brief` | `ai/claude/impact-brief/SKILL.md` |
| `/humain:tdd` | `ai/claude/tdd/SKILL.md` |
| `/humain:generate-docs` | `ai/claude/generate-docs/SKILL.md` |
| `/humain:conclude` | `ai/claude/conclude/SKILL.md` |
| `/humain:dev-review-external-docs` | `ai/claude/migrate/review-external-docs/SKILL.md` |
| `/humain:pm-add-feature` | `ai/claude/pm/add-feature/SKILL.md` |
| `/humain:pm-answer-questions` | `ai/claude/pm/answer-questions/SKILL.md` |
| `/humain:pm-design-feature` | `ai/claude/pm/design-feature/SKILL.md` |
| `/humain:pm-prep-demo` | `ai/claude/pm/prep-demo/SKILL.md` |
| `/humain:pm-prioritize` | `ai/claude/pm/prioritize/SKILL.md` |
| `/humain:pm-report-bug` | `ai/claude/pm/report-bug/SKILL.md` |
| `/humain:pm-review-progress` | `ai/claude/pm/review-progress/SKILL.md` |
| `/humain:pm-review-scope-change` | `ai/claude/pm/review-scope-change/SKILL.md` |
| `/humain:pm-update-requirement` | `ai/claude/pm/update-requirement/SKILL.md` |
| `/humain:qa-plan-tests` | `ai/claude/qa/plan-tests/SKILL.md` |
| `/humain:qa-report-defect` | `ai/claude/qa/report-defect/SKILL.md` |
| `/humain:qa-review-tests` | `ai/claude/qa/review-tests/SKILL.md` |
| `/humain:qa-verify-quality` | `ai/claude/qa/verify-quality/SKILL.md` |
| `/humain:ops-build` | `ai/claude/ops/build/SKILL.md` |
| `/humain:ops-deploy` | `ai/claude/ops/deploy/SKILL.md` |
| `/humain:ops-apply-iac` | `ai/claude/ops/apply-iac/SKILL.md` |
| `/humain:ops-measure-baseline` | `ai/claude/ops/measure-baseline/SKILL.md` |
| `/humain:ops-audit-dependencies` | `ai/claude/ops/audit-dependencies/SKILL.md` |
| `/humain:ops-plan-platform` | `ai/claude/ops/plan-platform/SKILL.md` |
| `/humain:architect-design-system` | `ai/claude/architect/design-system/SKILL.md` |
| `/humain:architect-design-feature` | `ai/claude/architect/design-feature/SKILL.md` |

---

## Agents — subagents invoked by skills

| Agent role | File to edit |
|---|---|
| Architect reviewer | `agents/architect-reviewer.md` |
| Developer implementer | `agents/developer-implementer.md` |
| Ops release reviewer | `agents/ops-release-reviewer.md` |
| PM reviewer | `agents/pm-reviewer.md` |
| QA reviewer | `agents/qa-reviewer.md` |
| Spec conformance reviewer | `agents/spec-conformance-reviewer.md` |

---

## Hooks — enforcement scripts (Claude Code)

| What it enforces | File to edit |
|---|---|
| Pre-write: blocks edits without active change context | `hooks/check-humain-context.sh` |
| Post-write: warns on cross-domain boundary violations | `hooks/check-domain-boundary.sh` |
| Post-write: incremental knowledge graph rebuild | `hooks/rebuild-graph.sh` |
| Session stop: writes session summary to `docs/session-logs/` | `hooks/write-session-summary.sh` |

---

## Templates used by skills

| Template | File |
|---|---|
| HLD document | `ai/claude/generate-docs/templates/hld-template.md` |
| LLD component | `ai/claude/generate-docs/templates/lld-component-template.md` |
| ADR | `ai/claude/generate-docs/templates/adr-template.md` |
| New project CLAUDE.md | `ai/claude/generate-docs/templates/CLAUDE.md.template` |
| System manifest schema | `ai/claude/generate-docs/templates/system-manifest.schema.yaml` |

---

## Codex users

Codex reads `AGENTS.md` from your **product repo root** — that file is your copy, installed by `init-project.sh`. Edit it directly; your customizations won't be overwritten by platform updates.

The hook scripts Codex uses are also copies in your product repo under `ai/codex/hook-scripts/`:

| What it enforces | File in your product repo |
|---|---|
| Pre-write: blocks edits without active change context | `ai/codex/hook-scripts/check-humain-context.sh` |
| Post-write: domain boundary check | `ai/codex/hook-scripts/check-domain-boundary.sh` |
| Session summary | `ai/codex/hook-scripts/write-session-summary.sh` |
| Knowledge graph rebuild | `ai/codex/hook-scripts/rebuild-graph.sh` |

To pull an updated hook script from the platform without touching `AGENTS.md`:

```bash
bash ~/tools/humain/ai/codex/install.sh .
# install.sh backs up existing hooks and skips AGENTS.md if already present
```

---

## Pulling platform updates into your fork

After merging upstream changes, skills and agents update immediately for Claude Code (they're referenced, not copied). For Codex hook scripts, re-run the installer above.

```bash
cd ~/tools/humain
git fetch upstream
git merge upstream/main   # review CHANGELOG.md first
```
