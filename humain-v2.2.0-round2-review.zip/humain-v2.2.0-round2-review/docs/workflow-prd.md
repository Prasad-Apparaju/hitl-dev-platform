# PRD Workflow — End to End

All steps from project creation to production, following the `/humain:dev-start-from-prd` path. Each node shows the HumAIn command that executes that step. Steps marked `(cond)` are conditional based on change tier or project configuration.

---

## 1. Project Setup

Setup ends when `/humain:architect-design-system` has produced approved HLDs, LLDs, and a delivery plan, and step 5 has generated the platform roadmap. No per-change work begins before that point.

```mermaid
graph TB
  subgraph SETUP["Project Setup — run once per project"]
    entry["/humain:dev-start-from-prd"]
    s0["Step 0 - Wire 8 hooks + settings.json + 4 ADR stubs"]
    s1["Step 1 - Customize CLAUDE.md"]
    s2["Step 2 - Initialize system manifest"]
    s3["Step 3 - Create first GitHub issue"]
    s4["Step 4 - Confirm ready"]
    design["/humain:architect-design-system - HLDs + LLDs + delivery plan"]
    graphify["graphify . + graphify hook install (if installed)"]
    s5["Step 5 - Generate platform roadmap - /humain:ops-plan-platform"]
    entry --> s0 --> s1 --> s2 --> s3 --> s4 --> design --> graphify --> s5
  end

  loop["Per-change delivery loop - GitHub issue + /humain:dev-practices"]

  s5 --> loop
```

### What each step produces

| Step | Command | Output | Required before |
|---|---|---|---|
| 0 | _(wires hooks automatically)_ | `.humain/hooks/`, `.claude/settings.json`, 4 ADR stubs | Everything else |
| 1 | _(fills CLAUDE.md)_ | Conventions and test framework locked in | Code generation |
| 2 | _(drafts manifest)_ | `docs/system-manifest.yaml` (provisional) | Architect design |
| 3 | `gh issue create` | First GitHub issue | Delivery plan |
| 4 | _(confirms ready)_ | — | — |
| Design | `/humain:architect-design-system` | HLDs, LLDs, `docs/decisions/issue-N.yaml` per slice | Per-change loop |
| Graphify | `graphify . && graphify hook install` | `graphify-out/graph.json` (optional) | First `/humain:dev-practices` run |
| 5 | `/humain:ops-plan-platform` | `docs/04-operations/platform-readiness.yaml` + roadmap issues (pipeline, staging env, observability) | First Tier 2+ production deploy (hard gate) |

---

## 2. Per-Change Loop — Requirements and Design (Steps 1–9)

One GitHub issue = one delivery slice. These steps run before any code is written.

```mermaid
graph TB
  subgraph REQ["Requirements (Steps 1-2)"]
    r1["1 - GitHub issue - /humain:pm-add-feature or /humain:pm-design-feature"]
    r2["2 - Figma review - manual (cond)"]
    r1 --> r2
  end

  subgraph DESIGN["Design (Steps 3-9)"]
    d3a["3 - Create feature branch issue/N-slug + commit initial current-change.yaml"]
    d3["3 - Impact analysis - /humain:dev-apply-change"]
    d3a --> d3
    d4["4 - ROI estimate (cond)"]
    d5["5 - HLD + LLD - /humain:dev-generate-docs"]
    d5a["5a - Security review design - /humain:dev-review-security --phase design (cond)"]
    d6["6 - IaC + migration scripts - /humain:ops-verify-scripts (cond)"]
    d7["7 - Test case planning - /humain:qa-plan-tests"]
    d8["8 - Training plan stub (cond)"]
    d9["9 - Decision packet - architect assembles docs/decisions/issue-N.yaml"]
    d3 --> d4 --> d5 --> d5a --> d6 --> d7 --> d8 --> d9
  end

  gate1["TA gate - /humain:ta-approve - design"]

  REQ --> DESIGN
  DESIGN --> gate1
```

---

## 3. Per-Change Loop — Build, Verify, and Ship (Steps 10–32)

```mermaid
graph TB
  subgraph TDD["Build TDD (Steps 10-17)"]
    t10["10 - Write tests RED - /humain:dev-tdd"]
    t11["11 - QA reviews tests - /humain:qa-review-tests"]
    t12["12 - Tests improve design - /humain:dev-tdd updates LLD"]
    t13["13 - Verify RED - run tests, all must fail"]
    t14["14 - Write code GREEN - /humain:dev-tdd"]
    t15["15 - Verify GREEN - run tests, coverage 90pct"]
    t16["16 - Refactor"]
    t16a["16a - Security review code - /humain:dev-review-security --phase code (cond)"]
    t17["17 - Convention checks - /humain:dev-check-conventions"]
    t10 --> t11 --> t12 --> t13 --> t14 --> t15 --> t16 --> t16a --> t17
  end

  subgraph VERIFY["Verify (Steps 18-22)"]
    v18["18 - Code review round 1 - /humain:dev-review-lld-adherence"]
    v19["19 - Code review round 2 - /humain:dev-review-lld-adherence"]
    v19a["19a - Architect code review - /humain:architect-review-code"]
    v20["20 - Rerun tests"]
    v21["21 - Reconcile docs - /humain:dev-generate-docs if changed"]
    v22["22 - QA post-handoff verify - /humain:qa-verify-quality"]
    v18 --> v19 --> v19a --> v20 --> v21 --> v22
  end

  subgraph ASSESS["Assess (Steps 23-24)"]
    a23["23 - Downstream impact brief - /humain:dev-impact-brief"]
    a24["24 - Rollout plan"]
    a23 --> a24
  end

  gate2["TA gate - /humain:ta-approve - code"]

  subgraph SHIP["Ship (Steps 25-29)"]
    s25["25 - Verify PR completeness"]
    s26["26 - Integration verify"]
    s27["27 - Figma comparison - manual (cond)"]
    s28a["28a - /humain:ops-backup-database (cond)"]
    s28b["28b - /humain:ops-migrate-database (cond)"]
    s28c["28c - /humain:ops-apply-iac (cond)"]
    s28d["28d - /humain:ops-setup-observability"]
    s28e["28e - /humain:ops-build"]
    s28f["28f - /humain:ops-detect-drift"]
    s28g["28g - /humain:ops-deploy"]
    s29["29 - /humain:ops-post-deploy-monitor or /humain:ops-rollback"]
    s25 --> s26 --> s27 --> s28a --> s28b --> s28c --> s28d --> s28e --> s28f --> s28g --> s29
  end

  subgraph POSTSHIP["Post-ship (Steps 30-32)"]
    p30["30 - /humain:ops-pentest (cond)"]
    p31["31 - 30-day ROI check (cond)"]
    p32["32 - 90-day ROI check + ADR update (cond)"]
    p30 --> p31 --> p32
  end

  TDD --> VERIFY --> ASSESS --> gate2 --> SHIP --> POSTSHIP
```

---

## 4. Human Approval Gates

These are points where work stops until a human explicitly approves before proceeding.

| Gate | Position | Command | Who approves |
|---|---|---|---|
| Design gate | After Package Decision Packet | `/humain:ta-approve` | Tech Architect |
| QA test review | Human Reviews Tests | `/humain:qa-review-tests` | QA |
| Architect code review | Architect Code Review | `/humain:architect-review-code` | Architect reviews PR on GitHub |
| QA verify | QA Post-Handoff Verification | `/humain:qa-verify-quality` | QA |
| Code gate | After Risk-Rated Rollout Plan | `/humain:ta-approve` | Tech Architect |

---

## 5. Full Command Reference

| Step | Command | Phase |
|---|---|---|
| 1 | `/humain:pm-add-feature` or `/humain:pm-design-feature` or `/humain:pm-report-bug` | Requirements |
| 3 | `/humain:dev-apply-change` | Design |
| 5 | `/humain:dev-generate-docs` | Design |
| 5a | `/humain:dev-review-security --phase design` (cond) | Design |
| 6 | `/humain:ops-verify-scripts` (cond) | Design |
| 7 | `/humain:qa-plan-tests` | Design |
| — | `/humain:ta-approve` — design gate | Gate |
| 10 | `/humain:dev-tdd` — write RED tests | Build |
| 11 | `/humain:qa-review-tests` | Build |
| 12 | `/humain:dev-tdd` — update LLD | Build |
| 14 | `/humain:dev-tdd` — write GREEN code | Build |
| 16 | `/humain:dev-tdd` — refactor | Build |
| 16a | `/humain:dev-review-security --phase code` (cond) | Build |
| 17 | `/humain:dev-check-conventions` | Build |
| 18 | `/humain:dev-review-lld-adherence` — impl vs LLD | Verify |
| 19 | `/humain:dev-review-lld-adherence` — impl vs tests | Verify |
| 19a | `/humain:architect-review-code` | Verify |
| 21 | `/humain:dev-generate-docs` (if design changed) | Verify |
| 22 | `/humain:qa-verify-quality` | Verify |
| 23 | `/humain:dev-impact-brief` | Assess |
| — | `/humain:ta-approve` — code gate | Gate |
| 28a | `/humain:ops-backup-database` (cond) | Ship |
| 28b | `/humain:ops-migrate-database` (cond) | Ship |
| 28c | `/humain:ops-apply-iac` (cond) | Ship |
| 28d | `/humain:ops-setup-observability` | Ship |
| 28e | `/humain:ops-build` | Ship |
| 28f | `/humain:ops-detect-drift` | Ship |
| 28g | `/humain:ops-deploy` | Ship |
| 29 | `/humain:ops-post-deploy-monitor` or `/humain:ops-rollback` | Ship |
| 30 | `/humain:ops-pentest` (cond) | Post-ship |
