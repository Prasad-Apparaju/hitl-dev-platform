# Workflow Model: Requirements

**Status:** Design (branch `design/workflow-model`). Captured before implementation, per HumAIn.
**Companion docs:** [01-design.md](01-design.md) · [02-rollout.md](02-rollout.md)

---

## 1. Problem

HumAIn exists to **let each role leverage AI to do their work and communicate everything the next
step needs to the harness, without dropping the best practices along the way.** The process isn't a
set of instructions telling people how to do their jobs; it's the scaffolding that lets an owner lean
on the harness for the legwork and the rigor, and spend their own attention on judgment. The process
is real and good, but the way it is *encoded* today undercuts that purpose with two structural flaws:

1. **Numbered steps go stale on every change.** Steps are identified by their global position
   (`Step 19a`, "rerun steps 18–20", "Steps 10–32", "after Step 9"). A number is a *position*
   used as an *identity*, so inserting or reordering one step renumbers everything downstream and
   every reference (across ~30 docs, the breadcrumb arrays, the skill summaries) goes stale at
   once. The recent `32 → 31` sweep (three releases of churn) was a direct symptom.

2. **The process is organized around commands and roles, not the work.** `command-map.md`
   conflates three independent things (the **process** (what happens, in order), the **commands**
   that execute a step, and the **roles** that are accountable) into one hand-maintained
   document. That makes it brittle and hard to specialize.

We also lack **stakeholder-legible workflow names.** "development" tells a PM nothing about what
kind of change it is or who initiates it.

## 2. The workflow contract (the mental model)

A **workflow** is a repeatable abstraction for *one whole change*. Every workflow obeys these
invariants:

- It decomposes into **phases → steps → substeps**, in order.
- Each step is **owned by a role**, and the harness gives that role a **skill/command** that does the
  heavy lifting with AI, carrying the best practices and the context the step needs, so the owner can
  focus on judgment and hand off complete, well-formed work rather than remembering every checklist.
- The chain is **seeded by the problem/requirement itself** (the issue); from there each step
  **consumes the previous step's outputs**. Every step has a defined input (the first the problem
  statement, the rest the prior step's work), so nothing starts from a blank page.
- **Handoffs are GitHub issues backed by updated documentation**: the docs are the source of
  truth; the issue is the baton.
- It all happens **inside one branch**.
- It spans **requirement → post-deployment**.
- It can **pause at any step** for human input or approval (a feature, not a stall).
- One workflow = **one whole change**, start to finish.

### Three tiers of identity (locked 2026-06-23)

Not every distinct kind of change needs its own workflow. The model has **three tiers**, so
granularity is earned rather than assumed:

| Tier | Definition | When to use it |
|---|---|---|
| **Workflow** | Owns its step sequence (its own/reordered/replaced spine). | The *structure or order* of steps genuinely differs: establishment setup, Incident (fix-first), Migration Slice (BI-driven). |
| **Profile** | A named, menu-visible **preset over the shared delivery spine**: selects conditional steps, required gates, initiator. | A recognizable change someone *initiates as a unit* (Feature, Fix, Tech Change, Upgrade, Security): same spine, different selection. |
| **Tag** | A composable label that **tunes required-evidence** within a profile; no steps of its own. | An intent that only changes *which evidence is required* (`refactor`, `perf`, `chore`, `tooling`, `infra`). |

The profile/tag a human picks only **proposes**; **impact analysis decides** the actual steps +
required-evidence, and the **floor** (the steps that can never be skipped) is enforced regardless of tier. So the tier is a
*legibility* choice, not a correctness one. Full taxonomy in [01-design.md §4](01-design.md); the
enforcement model in [03-execution-model.md](03-execution-model.md).

## 3. Goals

> **Guiding principle: the harness is a force-multiplier, not a rulebook.** Every goal below serves
> one purpose: let each role *leverage AI to do their work* and *communicate everything the next step
> needs* to the harness, with the best practices carried automatically, never to dictate how someone
> does their job. Separating structure from execution, deriving everything from one catalog,
> and determining the plan from impact analysis all exist so the owner supplies judgment while the
> harness supplies the legwork, context, and rigor.

| # | Goal |
|---|------|
| G1 | **Kill the global counter as an identity.** Steps are identified by a stable `key` + human name + phase. Numbers, where shown at all, are *derived display*, never stored references or hand-written prose. |
| G2 | **Separate structure from execution.** A workflow defines the *process* (ordered steps + gates); commands/skills do the *work*. The two are independently refinable: editing the process must not churn the commands, and vice versa. |
| G3 | **Stakeholder-legible workflows.** Name workflows by the *kind of whole change* so any role knows, from the name alone, who initiates, what goes in, and what comes out. |
| G4 | **Cover requirement → post-deployment** for every delivery workflow. |
| G5 | **Right initiator per workflow.** PM initiates functional change; engineering initiates technical change; ops initiates incidents. |
| G6 | **Define once, derive everything.** One catalog is the single source; the overview, breadcrumb, and (later) command-map and role guides are generated from it. |
| G7 | **Specializability.** Adding a phase, step, substep, or whole workflow is a small, local catalog edit; numbering and cross-references take care of themselves. |
| G8 | **Granularity is earned, not assumed.** A distinct *workflow* must justify itself by **materially different gates or steps**. Intent that only changes a label (and shares the same steps/gates) is a **change-kind tag** on the change, not a new workflow. Cheap-to-*define* (data-driven profiles) is not cheap-to-*use*: every named workflow is cognitive load for stakeholders and a branch the classifier can get wrong. |
| G9 | **The plan is determined by impact analysis, not predetermined.** The change's type/tier/steps/required-evidence are an **output** of impact analysis done **iteratively with the human**: the workflow is a refinable *proposal + template*, not a fixed pipeline. (See [03-execution-model.md](03-execution-model.md).) |
| G10 | **A non-skippable floor + informed-consent tailoring.** Some steps can never be skipped (the *floor*); the rest are skippable only via **tiered, informed, *recorded*** consent (the harness states what you miss, by whose authority, written to the ticket). Correctness is guaranteed by **enforced required-evidence**, not by the workflow name or a tag. |

> **Scope note.** This initiative began as a narrow fix ("docs go stale when steps are renumbered";
> minimal fix = cite steps by name). It has deliberately **evolved** into a broader model redesign
> (numberless catalog, phase-ribbon breadcrumb, named taxonomy, generated views). That evolution is
> accepted, but it raises **opportunity cost** against a plugin that is still stabilizing
> (recent Windows / YAML-parsing fixes). The mitigations are: strict **phasing** (each phase ships
> independently; see [02-rollout.md](02-rollout.md)) and **executability-first**: every step must resolve to a real executor before any breadcrumb or catalog polish (see Constraints).

## 4. Constraints

- **C1: Preserve the self-describing, portable change file** (`current-change.yaml`, issue #11):
  it must render the breadcrumb without the installed catalog.
- **C2: Do not gratuitously re-destabilize the change file / parser / migration.** Two bugs were
  just fixed there (v1.0.29 comment-stripping, v1.0.30 block-style + Windows). Any change to that
  surface must be additive and back-compatible, with a clear payoff.
- **C3: Back-compatible with existing v2 change files** in live projects.
- **C4: No regression in enforcement.** The gate/hook behavior (intake, edit-block, status
  gating) must keep working.
- **C5: Executability precedes presentation.** A workflow is not "done" until **every step
  resolves to an executor** (a skill/command, `manual`, or a deliberate `guided`). Polishing the
  breadcrumb or catalog must **not** precede closing the executor gaps. The remaining gap is small:
  two proposed steps (Baseline Measurement, Dependency+CVE Audit) need executors. The three commands
  an earlier audit flagged as missing actually exist as command+agent pairs (see
  [02-rollout.md §7](02-rollout.md)). Build the plumbing before the façade.

## 5. Non-goals (for this initiative / deferred to later phases)

- Generating `command-map.md` and the role guides from the catalog, *designed for, but landed in
  a later phase* (see [02-rollout.md](02-rollout.md)).
- Changing the internal behavior of any skill/command.
- Re-phasing the establishment (setup) workflows, optional enrichment, deferred.
- **Integrating Claude Design / Figma into the harness.** The model *requires* a UX artifact for
  user-facing changes (floor item #2 in [03-execution-model.md §3](03-execution-model.md)), but for now
  the artifact is captured **manually**, a Claude Design link, a Figma link, or a screenshot attached
  to the issue. A real tooling integration (generate or pull the design through the harness) is future
  work, this is the deliberate scope line: capture the *requirement* now, defer the *tooling*.

## 6. Success criteria

- Adding or reordering a step is a **one-line catalog edit + the new step's own prose**, zero
  cross-reference churn, zero renumber sweeps.
- A stakeholder can read a workflow name and correctly state its initiator, input, and output.
- The breadcrumb shows **no global step counter**; position is conveyed by phase + name + a
  derived, drift-resistant progress signal.
- `current-change.yaml`'s schema, the breadcrumb parser, and enforcement are unaffected or only
  additively extended.
- **Every workflow, profile, and tag is verified to actually run end to end**, and **the breadcrumb
  shows the correct status for all of them, in every case**: each phase of each workflow, the conditional
  steps a profile or tag switches on, substeps, skipped steps, deferred items, and branch-mismatch.
  This is checked by exercising the real artifacts (seed a `current-change.yaml` for each case and run
  the renderers), not by reading the catalog. A workflow/profile/tag whose breadcrumb is wrong or empty
  for any state is not done.
- **The harness meets Anthropic's standards** for the Claude Code features HumAIn ships, the full bar is
  [04-harness-acceptance-criteria.md](04-harness-acceptance-criteria.md). The criteria that directly
  bind this initiative: every `SKILL.md` passes the Part A schema gates; hook commands use absolute or
  `$CLAUDE_PROJECT_DIR` paths, never repo-relative; a step's `command` resolves against commands +
  agents + skills (not just `SKILL.md` dirs); `settings.json` stays valid JSON; and HumAIn hooks no-op
  cleanly in a project with no `.humain/`.
