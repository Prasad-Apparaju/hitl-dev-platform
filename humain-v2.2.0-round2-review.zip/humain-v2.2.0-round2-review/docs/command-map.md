# HumAIn Command Map

All commands across every workflow, showing where each one appears in the delivery lifecycle.

---

## 1. Project Lifecycle — High Level

The three setup paths converge into a single repeating change loop.

```mermaid
graph LR
  prd["/humain:dev-start-from-prd"]
  brown["/humain:dev-start-brownfield"]
  mig["/humain:dev-start-migration"]

  pm["PM phase"]
  arch["Architect phase"]
  dev["Dev phase — 31 steps"]
  qa["QA phase"]
  ops["Ops phase"]

  prd --> pm
  brown --> pm
  mig --> pm
  pm --> arch --> dev --> qa --> ops
  ops -->|"next change"| pm
```

---

## 2. Setup Flows

Each path produces a different starting artifact before the change loop begins.

```mermaid
graph TB
  subgraph PRD["Start from PRD"]
    s1["/humain:dev-start-from-prd"]
    s2["/humain:architect-design-system"]
    s3["Manifest + HLDs + LLDs + delivery plan"]
    s1 --> s2 --> s3
  end

  subgraph BROWN["Start brownfield"]
    b1["/humain:dev-start-brownfield"]
    b2["/humain:dev-generate-docs"]
    b3["/humain:architect-review-existing"]
    b4["Manifest + baseline docs + ADRs"]
    b1 --> b3
    b1 --> b2
    b2 --> b4
    b3 --> b4
  end

  subgraph MIG["Start migration"]
    m1["/humain:dev-start-migration"]
    m2["/humain:dev-review-external-docs"]
    m3["/humain:architect-design-system"]
    m4["Migration brief + target HLDs + LLDs"]
    m1 --> m2 --> m3 --> m4
  end
```

---

## 3. Per-Change Delivery Flow

The full command sequence for a Tier 2+ change, by role.

```mermaid
graph TB
  subgraph PM_PHASE["PM — Shape the change"]
    pm1["/humain:pm-prioritize"]
    pm2["/humain:pm-design-feature"]
    pm3["/humain:pm-add-feature"]
    pm4["/humain:pm-enhance-feature"]
    pm5["/humain:pm-update-requirement"]
    issue["GitHub Issue"]
    pm1 --> pm2 --> issue
    pm3 --> issue
    pm4 --> issue
    pm5 --> issue
  end

  subgraph ARCH_PHASE["Architect — Design"]
    a1["/humain:architect-design-feature"]
    a2["HLD + LLD approved"]
    ta1["/humain:ta-approve — design gate"]
    a1 --> a2 --> ta1
  end

  subgraph QA_PLAN["QA — Plan tests (step 7)"]
    q1["/humain:qa-plan-tests"]
  end

  subgraph DEV_PHASE["Developer — Build (steps 1-25)"]
    d1["/humain:dev-apply-change"]
    d2["/humain:dev-generate-docs"]
    d3["/humain:dev-tdd"]
    d4["/humain:dev-check-conventions"]
    d5["/humain:dev-review-lld-adherence"]
    d6["/humain:dev-review-security"]
    d7["/humain:architect-review-code"]
    d8["/humain:dev-impact-brief"]
    d9["/humain:dev-validate"]
    d1 --> d2 --> d3 --> d4 --> d5 --> d6 --> d7 --> d8 --> d9
  end

  subgraph QA_REVIEW["QA — Review and verify"]
    q2["/humain:qa-review-tests — step 11"]
    q3["/humain:qa-verify-quality — step 22"]
    q4["/humain:qa-report-defect"]
    q2 --> q3
    q3 -->|"fail"| q4
  end

  subgraph GATE["TA gate — code approval"]
    ta2["/humain:ta-approve — code gate"]
  end

  subgraph OPS_PHASE["Ops — Ship"]
    o1["/humain:ops-build"]
    o2["/humain:ops-deploy"]
    o3["/humain:ops-post-deploy-monitor"]
    o4["/humain:ops-rollback"]
    o1 --> o2 --> o3
    o3 -->|"issue"| o4
  end

  PM_PHASE --> ARCH_PHASE
  ARCH_PHASE --> QA_PLAN
  QA_PLAN --> DEV_PHASE
  DEV_PHASE --> QA_REVIEW
  QA_REVIEW --> GATE
  GATE --> OPS_PHASE
```

---

## 4. Ops Command Landscape

```mermaid
graph TB
  deploy["/humain:ops-deploy"]

  subgraph INFRA["Infrastructure"]
    iac["/humain:ops-apply-iac"]
    obs["/humain:ops-setup-observability"]
    drift["/humain:ops-detect-drift"]
    vs["/humain:ops-verify-scripts"]
    pt["/humain:ops-pentest"]
  end

  subgraph DATA["Data"]
    mdb["/humain:ops-migrate-database"]
    bdb["/humain:ops-backup-database"]
  end

  subgraph INCIDENT["Incident response"]
    inc["/humain:ops-incident"]
    roll["/humain:ops-rollback"]
    inc --> roll
  end

  deploy --> iac
  deploy --> obs
  deploy --> mdb
  mdb --> bdb
```

---

## 5. Commands at a Glance

### Setup — run once

| Command | When |
|---|---|
| `/humain:dev-start-from-prd` | New greenfield project |
| `/humain:dev-start-brownfield` | Existing codebase |
| `/humain:dev-start-migration` | System-to-system migration |
| `/humain:architect-design-system` | After PRD or migration setup |
| `/humain:architect-review-existing` | After brownfield manifest generation |
| `/humain:dev-review-external-docs` | After migration setup, before design |

### PM — any time before a change starts

| Command | When |
|---|---|
| `/humain:pm-design-feature` | Rough idea → structured requirement |
| `/humain:pm-add-feature` | Add new requirement to PRD |
| `/humain:pm-enhance-feature` | Enhance existing feature |
| `/humain:pm-update-requirement` | Change AC, scope, or priority on existing requirement |
| `/humain:pm-report-bug` | File a structured defect |
| `/humain:pm-prioritize` | Backlog prioritization |
| `/humain:pm-review-scope-change` | Impact of a proposed scope change |
| `/humain:pm-review-progress` | Sprint or milestone progress check |
| `/humain:pm-answer-questions` | Product questions from PRD and docs |
| `/humain:pm-prep-demo` | Demo script and talking points |

### Architect — design phase (steps 3–9)

| Command | When |
|---|---|
| `/humain:architect-design-feature` | Feature-level HLD + LLD with approval gates |
| `/humain:architect-review-code` | Human code review at step 19a |

### QA — across design and implementation

| Command | Step | When |
|---|---|---|
| `/humain:qa-plan-tests` | 7 | After LLD approval, before TDD |
| `/humain:qa-review-tests` | 11 | After RED phase; gates implementation start |
| `/humain:qa-verify-quality` | 22 | Post-handoff independent verification |
| `/humain:qa-report-defect` | 22+ | When verify-quality fails |

### Developer — implementation (steps 1–25)

| Command | Step(s) | When |
|---|---|---|
| `/humain:dev-practices` | 1 | Entry point for the 31-step workflow |
| `/humain:dev-apply-change` | 3 | Change planning and impact analysis |
| `/humain:dev-generate-docs` | 5–6 | HLD/LLD for a component |
| `/humain:dev-tdd` | 10–16 | Red→Green→Refactor cycle |
| `/humain:dev-check-conventions` | 17 | Semgrep, secrets, manifest drift, Mermaid lint |
| `/humain:dev-review-lld-adherence` | 18 | Code vs LLD conformance check |
| `/humain:dev-review-security` | 19 | Threat model, SAST, or security baseline |
| `/humain:dev-impact-brief` | 23 | Downstream impact and rollout plan |
| `/humain:dev-validate` | Any | Iterative check→fix→re-check before done |
| `/humain:dev-conclude` | Any | Slack design thread → GitHub ADR + issue |

### Gates

| Command | When |
|---|---|
| `/humain:ta-approve` | Advance design gate (after LLD approval) or code gate (before Ops) |

### Ops — after code gate

| Command | When |
|---|---|
| `/humain:ops-build` | Validate and run build pipeline |
| `/humain:ops-deploy` | Full deployment workflow |
| `/humain:ops-plan-platform` | Platform readiness register + roadmap (onboarded → delivery-ready) |
| `/humain:ops-apply-iac` | Infrastructure-as-code changes |
| `/humain:ops-migrate-database` | Database migration before deploy |
| `/humain:ops-backup-database` | Pre-deploy or scheduled backup |
| `/humain:ops-setup-observability` | Logging, metrics, alerting |
| `/humain:ops-verify-scripts` | Script/tooling validation |
| `/humain:ops-post-deploy-monitor` | Post-deploy monitoring |
| `/humain:ops-detect-drift` | Config or infrastructure drift |
| `/humain:ops-pentest` | Penetration test workflow |
| `/humain:ops-rollback` | Roll back a deployment |
| `/humain:ops-incident` | P0 incident response |

### Utility — available at any time

| Command | Purpose |
|---|---|
| `/humain:help` | Find the right command for any situation |
| `/humain:dev-update` | Update the plugin to the latest version |
