# Workflow Steps — Full Detail

Step-by-step reference for the 31-step HumAIn change workflow. The SKILL.md entrypoint has the summary; this file has the detail.

---

## Prerequisites

Before the GitHub Issue step, ensure these artifacts exist:

| Artifact | New project | Brownfield |
|---|---|---|
| `docs/system-manifest.yaml` | Run `/humain:architect-design-system` from your PRD | Run `/humain:dev-start-brownfield` (maps codebase, generates manifest, runs architect review) |
| HLDs + LLDs | Produced by `/humain:architect-design-system` | Produced by brownfield baseline sprint |
| `docs/03-engineering/testing/test-registry.yaml` | Created empty by `/humain:architect-design-system`; populated as changes land | Populate during baseline sprint from existing test catalog |
| `docs/04-operations/incident-registry.yaml` | Starts empty; populated after each production incident | Seed during baseline sprint: "what broke in the last 6 months?" |

If you have not done this yet, run `/humain:dev-start-from-prd`, `/humain:dev-start-brownfield`, or `/humain:dev-start-migration` — choose the one that fits your situation.

**Brownfield accuracy note:** The manifest and LLDs produced by the baseline sprint start at 55–75% accuracy and improve as changes correct each area. For the first several changes on a brownfield project, treat AI output from the Update Docs, AI Generates Tests (RED), and Generate Code (GREEN) steps as drafts requiring closer human review than on a well-established codebase.

---

## Steps 1–2: Requirements

**1. GitHub Issue**
Describe the change, root cause, and proposed solution. If no issue exists, create one with `gh issue create` before proceeding. Use `/pm/add-feature` for features or `/pm/report-bug` for bugs.

> **Brownfield:** PM skills apply identically once onboarded — `/humain:pm-design-feature` and `/humain:pm-add-feature` work the same way for new features on a brownfield project as on a greenfield one.

**2. Figma Review (conditional)**
If a Figma design exists, the PM or developer reads the Figma file directly and adds requirements, interactions, and visual specs into the GitHub issue. No command — this is a manual extraction step.

---

## Steps 3–9: Design

**3. Impact Analysis** — use `/humain:dev-apply-change`
Reads `system-manifest.yaml`, test registry (`docs/03-engineering/testing/test-registry.yaml`), and incident registry (`docs/04-operations/incident-registry.yaml`) to identify affected components, APIs, configs, and dependencies. Produces an effort estimate. Outputs `.humain/current-change.yaml` with change ID, tier, affected domains, source artifact paths, and `token_tracking.estimated` — a phase-level token cost estimate based on artifact file sizes. See `roi-estimation.md` for the estimation method.

**4. ROI Estimate (conditional)**
If the Impact Analysis effort estimate exceeds 1 day, record the ROI section in `.humain/current-change.yaml` under `roi_estimate`: expected outcome (specific and falsifiable), baseline metric (measured now, not estimated), measurement plan, 30/90-day checkpoints, and `token_tracking.estimated.total_cost_usd` as the "AI dev tokens" cost line item. See `roi-estimation.md` for the template. Post a pointer comment on the GitHub issue: `gh issue comment <issue-number> --body "ROI estimate filed — see decision packet at \`docs/decisions/issue-<N>.yaml\`"`.

**5. Update Docs** — use `/humain:dev-generate-docs`
Using the affected component list from `.humain/current-change.yaml` (Impact Analysis) and Figma specs from Figma Review (if available): create or update HLD at `docs/02-design/technical/hld/<feature>.md` and LLD at `docs/02-design/technical/lld/<component>.md`. Update ADRs for any new design decisions. Architect must approve the HLD before LLD generation begins. LLD must be approved before implementation starts.

> **Brownfield:** If the LLD being updated was produced by the baseline sprint rather than a previous change, verify it against the actual code before using it as a code-generation source. Baseline-sprint LLDs are drafts — they may not yet reflect the true behavior of the component.

**6. Update IaC and Verify Ops Scripts**
Using the IaC section of `.humain/current-change.yaml` (Impact Analysis) and the LLD at `docs/02-design/technical/lld/<component>.md` (Update Docs): write Terraform/Kubernetes manifests, database migration scripts, rollback migrations, and deployment configs. Only if Impact Analysis identified IaC changes.

**Exit criterion — run `/humain:ops-verify-scripts <change-ID> --level syntax` before moving to Test Case Planning.** This checks that every expected artifact exists on disk, passes syntax validation, and passes a dev dry-run. Do not start TDD (AI Generates Tests (RED)) with ops scripts that have never been validated — a broken migration discovered at the Build/Migrate/Apply/Deploy step costs significantly more to fix than one caught here.

For database migrations, also run the migration against the dev database and revert it to confirm the schema roundtrip works. Record `ops_scripts.verified_at` in `.humain/current-change.yaml` before proceeding.

**7. Test Case Planning** — use `/humain:qa-plan-tests`
Using the LLD at `docs/02-design/technical/lld/<component>.md` (Update Docs), incident registry, and test registry: QA queries incident history with `/humain:qa-plan-tests` and contributes regression-required scenarios before the TDD cycle starts. The developer produces the full list of new tests, updated tests, removed tests, and regression tests. Each QA-contributed scenario must be acknowledged before the TDD cycle begins. Record the test plan in `.humain/current-change.yaml` under `tests.plan`. The issue is not the home for the test plan — it lives in the context file and decision packet.

> **Empty incident registry (new project or no incidents logged yet):** Skip the incident history query. Record the test plan from the LLD alone and note "incident registry empty" in `.humain/current-change.yaml`. The registry will accumulate entries as production incidents occur.

**8. Training Plan Stub (conditional)**
If the change introduces a new architectural pattern, external system, framework, ML/AI technique, or significant mental-model-changing refactor: draft a stub at `docs/03-engineering/training/<capability>.md`. Triggers: new architectural pattern, new external system, new framework, new ML/AI technique, or a significant mental-model-changing refactor. New endpoints, bug fixes, and preserving-the-model refactors do not require a training plan.

**9. Package Decision Packet** — use `/humain:architect-design-feature`
Architect assembles `docs/decisions/issue-<N>.yaml` (one per slice) using `ai/shared/templates/decision-packet-template.yaml`. Fields: issue number, affected domain from `system-manifest.yaml`, LLD path from Update Docs, IaC plan from Update IaC, test plan from Test Case Planning, training stub path from Training Plan Stub if applicable. Constraint: each packet must touch exactly one manifest domain — if two slices would modify the same domain, they are sequential, not parallel. Architect reviews each packet, sets `approvals.architecture: approved` in `.humain/current-change.yaml`, then hands one packet per slice to each assigned developer. `/architect/design-feature` runs the Impact Analysis through Package Decision Packet steps as a single guided session including slice decomposition and packet generation.

---

## Recording Token Costs (optional — for mature teams and pilots)

Token-cost tracking is a calibration layer, not a baseline requirement. Teams that are just adopting the process should skip this step until the workflow itself is running smoothly. Once established, it produces the data that makes ROI estimates credible and lets teams identify which workflow phases are disproportionately expensive.

If your team is tracking costs: at the end of each Claude Code session, Claude Code displays the session cost. Record it in `.humain/current-change.yaml` under `token_tracking.actual.sessions`:

```yaml
token_tracking:
  actual:
    sessions:
      - date: "YYYY-MM-DD"
        steps_covered: [10, 11, 12]   # which workflow steps ran this session
        cost_usd: 0.52                # from Claude Code session summary
```

Do this before closing the session — the summary is not persisted anywhere else. Sum all session costs to get `token_tracking.actual.total_cost_usd`.

---

## Steps 10–17: Build (TDD Cycle)

> Use the `/humain:dev-tdd` skill for the AI Generates Tests (RED), Tests Improve the Design, and Generate Code (GREEN) steps. See `tdd-design.md` for the conceptual background.

**10. AI Generates Tests (RED)** — use `/humain:dev-tdd`
Developer passes the LLD path from the decision packet to `/humain:dev-tdd`. The skill reads `docs/02-design/technical/lld/<component>.md` (Update Docs) and `system-manifest.yaml` directly — it does not read the decision packet file itself. Generates maximum test coverage: happy paths, error paths, edge cases, preconditions, boundary entities, contract compliance from manifest facade APIs. Writes test files to `tests/`. Registers each test in `docs/03-engineering/testing/test-registry.yaml`. No implementation code exists at this point.

**11. Human Reviews Tests** — use `/humain:qa-review-tests`
QA (or developer on small teams) reads the same LLD (`docs/02-design/technical/lld/<component>.md`, Update Docs) and queries the incident registry to identify gaps in the generated tests. Adds edge cases AI missed, adds integration scenarios from domain knowledge, removes trivial or wrong tests. Updates `docs/03-engineering/testing/test-registry.yaml` for every test added or removed. If QA ran `/humain:qa-plan-tests` at design time, verify those scenarios are present before approving.

> **Empty incident registry:** Skip the incident registry query. Add edge cases from domain knowledge and LLD review alone.

**12. Tests Improve the Design** — use `/humain:dev-tdd`
`/humain:dev-tdd` analyzes the test files in `tests/` against the LLD at `docs/02-design/technical/lld/<component>.md`. For each test that covers behavior the LLD does not describe, proposes a specific LLD update. LLD is updated at the same path before any code is written. If LLD changes are significant, architect re-reviews and confirms before proceeding.

**13. Verify RED**
Run the full test suite. All new tests must fail (no implementation exists). If any new test passes: either fix the test (it is wrong) or remove it (LLD already describes existing behavior). Resolve all ambiguities before proceeding — a passing test before implementation means the spec is unclear or redundant.

**14. Generate Code (GREEN)** — use `/humain:dev-tdd`
`/humain:dev-tdd` reads the failing test files in `tests/`, the updated LLD at `docs/02-design/technical/lld/<component>.md` (Tests Improve the Design), `system-manifest.yaml`, and `CLAUDE.md`. Generates the simplest implementation that makes all failing tests pass. Does not anticipate future requirements.

**15. Verify GREEN**
Run the full test suite (new + existing). All must pass. If existing tests fail: regression — fix the regression and re-run Generate Code (GREEN) before proceeding. Do not proceed with a broken existing test suite.

**16. Refactor**
Simplify passing code. Remove duplication, improve naming. Rerun tests after each change. Done when no further simplification is possible without breaking a test. Do not introduce new behavior during refactor.

**17. Convention Checks** — use `/humain:dev-check-conventions`
Run `semgrep scan --config .semgrep/ --error` and manifest drift check against `convention-checks.yaml`. Exit criterion: zero violations. Fix all violations before proceeding. Do not defer to CI — catching here avoids a failed CI run.

---

## Steps 18–22: Verify

**18. Code Review Round 1** — use `/humain:dev-review-lld-adherence`
Uses the `spec-conformance-reviewer` agent. Reads implementation files plus the LLD at `docs/02-design/technical/lld/<component>.md` (Tests Improve the Design) and `system-manifest.yaml`. Reviews: structure, security, LLD adherence, naming conventions. Fix all CRITICAL and HIGH findings before proceeding. MEDIUM findings are documented for Round 2.

**19. Code Review Round 2** — use `/humain:dev-review-lld-adherence`
Uses the `spec-conformance-reviewer` agent. Reads implementation files, test files in `tests/`, and the test plan from `.humain/current-change.yaml` (Test Case Planning). Reviews: edge cases, regressions, test quality, and completeness against the test plan. Fix all findings. Rerun full test suite after fixes.

**19a. Architect Code Review** — use `/humain:architect-review-code`
Creates the GitHub PR and requests the architect's review. The PR description includes: issue link, LLD path, decision packet path, AI findings carried forward from rounds 1 and 2, and a 7-item judgment checklist for the architect to complete on GitHub. The architect reviews on GitHub using line comments and the review UI — not in the Claude session.

The checklist covers: (1) business logic — does the code solve the right problem, not just satisfy the spec? (2) architectural consistency — is this consistent with how similar problems are solved elsewhere? (3) domain boundary integrity — no code reaches into another domain's internals? (4) hidden coupling — shared mutable state, implicit ordering, timing assumptions not in the LLD? (5) complexity — could this be simpler? (6) naming — do names communicate intent to a future reader? (7) error handling — failures diagnosable from logs; errors surfaced correctly?

The architect approves or requests changes on GitHub. Revisions are classified by severity: Minor (naming, simplification) → return to Refactor; Significant (logic, structure, domain violation) → return to Generate Code (GREEN); Design change (fundamental approach wrong) → return to Tests Improve the Design. The outcome is recorded in `.humain/current-change.yaml` under `approvals.architect_code_review` and posted as a GitHub issue comment. **The PR is not merged here — merging happens at Build/Migrate/Apply/Deploy.**

**20. Rerun Tests**
Confirm no regressions from review fixes. All tests must pass.

**21. Reconcile Docs**
Compare implementation against the LLD at `docs/02-design/technical/lld/<component>.md`. If they diverge, make the decision explicit:
- **Implementation reveals a better design** → update the LLD using `/humain:dev-generate-docs`, have architect confirm, document decision in PR description or ADR
- **Implementation drifted from the intended design** → fix the code, rerun the Code Review Round 1 through Rerun Tests steps
Never silently normalize drift.

**22. QA Post-Handoff Verification** — use `/humain:qa-verify-quality`
Developer has delivered a stable build with all tests passing and docs reconciled (Reconcile Docs). QA runs independent verification against the running build: verify each acceptance criterion, run exploratory tests beyond the happy path, and probe failure modes from the incident registry. If any AC fails or a blocking defect is found, QA runs `/humain:qa-report-defect` and sets `approvals.qa: blocked` in `.humain/current-change.yaml`. Promotion to Assess is blocked until QA lifts the block.

> **Empty incident registry:** Skip the failure-mode probe from incident history. Run exploratory tests based on the acceptance criteria and LLD edge cases instead.

---

## Steps 23–24: Assess

**23. Downstream Impact Brief** — use `/humain:dev-impact-brief`
`/humain:dev-impact-brief` reads `.humain/current-change.yaml`, `git diff main...HEAD`, `system-manifest.yaml`, incident registry, and test registry. Produces a 5-section brief. Section 5 contains the rollout strategy draft including risk tier and go/no-go criteria.

> **Empty incident registry:** `/humain:dev-impact-brief` will produce section 5 without historical failure context. The rollout strategy draft will be based on the change's risk tier alone — ops should add manual go/no-go criteria to compensate for the missing incident signal.

**24. Risk-Rated Rollout Plan** — use `/humain:ops-review-release`
Ops reads the rollout strategy from the Downstream Impact Brief's section 5 and the incident registry for the affected domains. Reviews and approves canary tier and go/no-go criteria, or adjusts them. The approved plan must exist; it will be added to the open PR description at the Verify PR Completeness step.

> **Empty incident registry:** Base the canary criteria on the change's risk tier and known failure modes from the LLD rather than historical incidents. Flag this in the rollout plan: "No incident history available — criteria are forward-looking only."
>
> **First release (no prior version in production):** Canary over existing traffic is not possible. Use a direct deploy with a manual smoke-test gate: deploy to staging, run the acceptance criteria from the PRD (FR-<ID> linked in the issue), then promote to production. "Rollback" means tearing down the deployment; there is no prior version to restore. Document this explicitly in the rollout plan.

---

## Steps 25–30: Ship

**25. Verify PR completeness**
The PR was created at the Architect Code Review step. This step confirms it contains all required artifacts before proceeding to integration verification. Check that the PR description includes: issue link, HLD/LLD paths (`docs/02-design/technical/`), IaC from Update IaC, implementation code, test files from `tests/`, decision packet (`docs/decisions/issue-<N>.yaml`, Package Decision Packet), impact brief (Downstream Impact Brief), and the approved rollout plan (Risk-Rated Rollout Plan). If any are missing, add them to the PR description now. Also copy `token_tracking.actual` from `.humain/current-change.yaml` into `docs/03-engineering/costs/token-cost-registry.yaml` and recompute the aggregate block.

**26. Integration Verification** — use `/humain:architect-verify-traceability`
Lead runs each slice E2E and verifies cross-slice composition: do the slices integrate correctly when all are deployed together? Also verifies the traceability chain for each slice: GitHub issue → design PR merged → implementation matches LLD → test files cover the spec → impact brief complete → rollout plan approved. Signs off or sends back with findings.

**27. Figma Comparison (conditional)**
If Figma design exists, lead compares running implementation to the Figma spec from Figma Review screen by screen. Lists and resolves all differences. Exit criterion: zero unresolved differences before merge.

**28. Build, Migrate, Apply IaC, Configure Observability, and Deploy**
Ops executes this sequence — each step gates the next:

1. **Database backup** (`/humain:ops-backup-database backup <change-ID>`) — required before any migration; always creates a labeled, verified snapshot recorded in `.humain/current-change.yaml`. Skip if no migrations exist.
2. **Database migrations** (`/humain:ops-migrate-database`) — conditional; only when the change includes migrations. Delegates backup verification to Step 1, runs dry-run, requires explicit `MIGRATE` confirmation, applies, verifies schema. Must complete before app deploy.
3. **Apply IaC** (`/humain:ops-apply-iac`) — conditional; only when infrastructure changes exist. Dry-run first, applies with explicit `APPLY` confirmation, destructive changes require `CONFIRMED`.
4. **Observability setup** (`/humain:ops-setup-observability`) — **required gate for all Tier 2+ changes**. Creates dashboards and alerts for every go/no-go criterion in the rollout plan. Verifies alert routing to on-call. `/humain:ops-deploy` will refuse to run if `observability.status: configured` is not set.
5. **Build** (`/humain:ops-build`) — verifies CI passed, confirms artifact digest, runs health/smoke checks.
6. **Deploy** (`/humain:ops-deploy`) — reads artifact and rollout plan, confirms deployment configuration with operator, executes deployment, runs post-deployment verification. Checks all gates are complete (backup, migrations, IaC, observability) before proceeding.
7. **Canary monitoring** (`/humain:ops-monitor-canary`) — at each promotion step, reads observability data and produces a go/no-go recommendation; human makes the final call
8. **Close the change** — once the PR is merged and the deploy is verified, set the top-level `status: merged` in `.humain/current-change.yaml`. This is the terminal state: the session gate treats a merged change as inactive, so the next change on the branch goes through intake instead of inheriting this one. Leaving the status un-set is how a stale change file lingers on `main`.

Remaining slices that have not yet merged must rebase against main and rerun the Convention Checks through Code Review Round 2 steps before their own merge.

> **First release:** Follow the direct-deploy plan approved at the Risk-Rated Rollout Plan step. Skip `/humain:ops-monitor-canary` — run the smoke suite manually. Observability setup is still required even on first release.

**29. Promote or Rollback**
At each canary step, verify all go/no-go criteria from the approved plan (Risk-Rated Rollout Plan). If all met: promote to next tier. If any fail: pause and investigate before deciding — do not roll back automatically on noise. Lead makes the final call.

- **To promote:** continue deployment per the rollout plan steps
- **To roll back:** run `/humain:ops-rollback` — assesses side effects (including data written since deployment), presents rollback plan, requires `ROLLBACK` confirmation. If a database migration ran and has no rollback migration, it delegates to `/humain:ops-backup-database restore` to restore from the pre-migration snapshot.
- **After final promotion — required for all Tier 2+ changes:** run `/humain:ops-post-deploy-monitor <change-ID>`. Soak duration is risk-scaled: Low 1h (check every 30m), Medium 4h (every 1h), High 12h (every 2h), Critical 24h (every 4h). The change is **not complete** until this produces a STABLE verdict. A WATCH verdict requires a follow-up check. A ROLLBACK verdict triggers `/humain:ops-rollback`.

If rollback was performed: re-open the issue, investigate root cause, and re-run from the Verify PR Completeness step.

> **First release:** There is no prior version to restore. If the smoke-test gate fails, tear down the deployment and treat the failure as a blocking defect — open a GitHub issue, fix it, and re-run from the Verify PR Completeness step.

---

## Steps 30–31: Post-Ship

**30. 30-Day ROI Check (conditional)**
Only if the ROI Estimate step was done. Reads expected outcome and baseline metric from `.humain/current-change.yaml` under `roi_estimate`. Developer + lead assess whether the metric is moving in the right direction. Also check whether `token_tracking.actual.total_cost_usd` was within 50% of estimated — if not, add a note to the cost registry entry explaining the variance. See `roi-estimation.md` for the review template.

**31. 90-Day ROI Check (conditional)**
Only if the ROI Estimate step was done. Reads `roi_estimate` from `.humain/current-change.yaml` and 30-day findings from the 30-Day ROI Check. Lead + PM compare actual vs estimated ROI. Update ADR at `docs/02-design/technical/adrs/` with an Actual Outcome section. Review `docs/03-engineering/costs/token-cost-registry.yaml` aggregate block — if 5+ entries exist, apply the optimization signals from the registry template. See `roi-estimation.md`.
