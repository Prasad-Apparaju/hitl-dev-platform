#!/usr/bin/env bash
# UserPromptSubmit hook: HumAIn status banner.
# - No active change for this branch → inject the mandatory intake directive (forces change
#   selection before any work; see humain-gate.sh for the SessionStart counterpart).
# - Active change → show the breadcrumb (header + windowed step trail) on every prompt,
#   driven entirely by the self-describing `workflow` block in current-change.yaml.
# - Branch ↔ change mismatch (issue #12) → append a warning marker.
#
# The step model is NEVER hardcoded here — it is read from the change file via _steps.sh, so
# this banner and the persistent status line (statusline-humain.sh) can never drift.

[[ -d ".humain" ]] || exit 0  # not a HumAIn project — skip silently

# Source .env if present — makes LLM keys (e.g. for Graphify) available without manual export.
if [[ -f ".env" ]]; then
  set -a; source ".env"; set +a
fi

# Shared parser/rendering library (lives beside this script in both source and plugin layouts).
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=/dev/null
source "$SCRIPT_DIR/_steps.sh"

HUMAIN_FILE=".humain/current-change.yaml"
SEP="━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
CURRENT_BRANCH=$(git branch --show-current 2>/dev/null || echo "")

# ── No active change → force intake (the "you must pick an issue + workflow" gate) ─────────────
if ! humain_change_active "$HUMAIN_FILE"; then
  humain_intake_directive
  exit 0
fi

# ── Active change → render the breadcrumb from the embedded workflow block ─────────────────────
# Header fields. change_id/tier are top-level; the human-readable step name + phase come from
# the current_step compat pointer; the step number/total/trail come from the embedded block.
change_id=$(humain_scalar "$HUMAIN_FILE" change_id)
tier=$(humain_scalar "$HUMAIN_FILE" tier)
step_name=$(humain_cs_field "$HUMAIN_FILE" name)    # tolerant of quoted/unquoted, block/flow
phase=$(humain_cs_field "$HUMAIN_FILE" phase)

# Branch reconciliation marker (issue #12). Only the hard mismatch is shown — `unverifiable`
# (a non-issue/* branch with no expected_branch) is silently tolerated, not flagged every prompt
# (issue #15: it was permanent noise on long-lived integration branches).
warn=""
if [[ "$(humain_branch_reconcile "$HUMAIN_FILE" "$CURRENT_BRANCH")" == "mismatch" ]]; then
  warn="   ⚠ branch=${CURRENT_BRANCH} ≠ ${change_id} — context may be stale; run /humain:dev-switch-context"
fi

# Render the trail only when the workflow block actually yields a current step. A workflow block
# that parses to zero steps (malformed/legacy) would otherwise print "Step ? / N" silently —
# instead fall through to the migrate hint (issue #15).
cur=$(humain_current_n "$HUMAIN_FILE")
echo "$SEP"
if humain_has_workflow "$HUMAIN_FILE" && [[ -n "$cur" ]]; then
  wf=$(humain_workflow_field "$HUMAIN_FILE" id)
  [[ -z "$step_name" ]] && step_name=$(humain_current_label "$HUMAIN_FILE")
  ribbon=$(humain_render_ribbon "$HUMAIN_FILE")
  # Phase 2: phase ribbon + named, numberless trail. No global "Step N / total" counter.
  printf "  HumAIn %s ▸ %s ▸ %s\n" "$wf" "$change_id" "${ribbon:-${phase:-$wf}}"
  printf "  ▸ %s: %s   ·   tier %s\n" "${phase:-$wf}" "$step_name" "${tier:-?}"
  [[ -n "$warn" ]] && echo "$warn"
  echo ""
  printf "  %s\n" "$(humain_render_trail "$HUMAIN_FILE" "" "$step_name")"
else
  # Back-compat: pre-v2 file (bare current_step, no workflow block) OR a workflow block that
  # couldn't be parsed into steps — either way, point the user at the migration.
  num=$(humain_cs_field "$HUMAIN_FILE" number)
  printf "  HumAIn — %s  •  Step %s: %s\n" "${phase:-change}" "${num:-?}" "$step_name"
  printf "  change: %s  •  tier: %s\n" "$change_id" "${tier:-?}"
  [[ -n "$warn" ]] && echo "$warn"
  echo ""
  echo "  (step trail unavailable — run /humain:dev-update to migrate this change to the"
  echo "   self-describing workflow format)"
fi
echo "$SEP"
exit 0
