#!/usr/bin/env bash
# _steps.sh — shared HumAIn breadcrumb parser. Sourced by welcome.sh and statusline-humain.sh.
#
# This is the ONLY place that knows how to read the self-describing `workflow` block embedded
# in .humain/current-change.yaml. Both renderers source this file so the banner and the status
# line can never drift on step count or labels (the four-way drift that motivated this design).
#
# It is intentionally dependency-free (awk only — no jq/yq/python). It relies on the embedded
# steps being written as single-line YAML flow maps, exactly as the schema and the start-skills
# produce them:
#
#   workflow:
#     id: development
#     version: "1.0.28"
#     total: 31
#     steps:
#       - { n: 1,   key: issue,       label: "Issue",   status: done }
#       - { n: 19a, key: arch_review, label: "ArchRvw", status: current }
#       - { n: 20,  key: rerun,       label: "Rerun",   status: open }
#
# Status values: done (✓) · current (▶) · open (·).

# humain_python → echo the first working Python interpreter, or return 1 if none (issue #14).
# On Windows, `python3` is usually the Microsoft Store stub: it's on PATH but exits non-zero and
# runs nothing, so a hard-coded `python3` makes every hook silently no-op. The `import sys` smoke
# test rejects the stub. Prefers $HUMAIN_PY (set by the wrapper) to avoid re-probing per call.
humain_python() {
  if [[ -n "${HUMAIN_PY:-}" ]] && command -v "$HUMAIN_PY" >/dev/null 2>&1; then echo "$HUMAIN_PY"; return 0; fi
  local c
  for c in python3 python py; do
    if command -v "$c" >/dev/null 2>&1 && "$c" -c "import sys" >/dev/null 2>&1; then echo "$c"; return 0; fi
  done
  return 1
}

# humain_has_workflow <yaml> → exit 0 if the file has an embedded `workflow:` block with steps.
humain_has_workflow() {
  local f="$1"
  [[ -f "$f" ]] || return 1
  awk '/^workflow:/{w=1} w && /^[ ]+steps:/{print "yes"; exit}' "$f" | grep -q yes
}

# humain_workflow_field <yaml> <field> → echo a scalar field (id|version|total|title) from the
# workflow block. Reads only the indented lines inside `workflow:` (before `steps:`).
humain_workflow_field() {
  local f="$1" field="$2"
  awk -v key="$field" '
    /^workflow:/        { w=1; next }
    w && /^[^ ]/        { exit }                       # left the workflow block
    w && /^[ ]+steps:/  { exit }                       # stop at the steps list
    w {
      line=$0
      if (line ~ "^[ ]+" key ":") {
        sub("^[ ]+" key ":[ ]*", "", line)
        gsub(/^"|"$/, "", line)                        # strip surrounding quotes
        sub(/[ ]+#.*/, "", line)                       # strip trailing comment
        gsub(/[ ]+$/, "", line)
        print line; exit
      }
    }
  ' "$f"
}

# humain_steps <yaml> → emit one line per step as: n|label|status
# Order is preserved. Substeps (e.g. 19a) come through as their literal n.
humain_steps() {
  local f="$1"
  # Handles BOTH single-line flow maps ("- { n: 1, key: …, status: done }") and
  # multi-line block style ("- n: 1\n  key: …\n  status: done"). Both are valid YAML; the
  # writer emits flow style, but anything that hand-edits the file (incl. an agent flipping
  # statuses) may emit block style — the breadcrumb must render either (issue #15).
  awk '
    function field(t, key,   v) {        # extract `key:`-value from a block line, unquoted
      v=t; sub("^[ ]*" key ":[ ]*","",v); sub(/[ ]+#.*/,"",v); sub(/[ ]*$/,"",v)
      gsub(/^"|"$/,"",v); gsub(/^'"'"'|'"'"'$/,"",v); return v
    }
    function flush() { if (have) { if (st=="") st="open"; print n "|" lbl "|" st "|" ph } have=0; n=""; lbl=""; st=""; ph="" }
    /^workflow:/        { w=1; next }
    w && /^[ ]+steps:/  { s=1; next }
    s {
      line=$0
      if (line ~ /^[^ ]/)            { flush(); exit }          # next top-level key ends steps
      if (line ~ /^[ ]+- *\{/) {                                 # ── flow style (self-contained)
        flush()
        n=line;   sub(/.*[{,][ ]*n:[ ]*/,    "", n);   sub(/[ ]*[,}].*/, "", n);   gsub(/["{} ]/,"",n)
        lbl=line; sub(/.*[,{][ ]*label:[ ]*/, "", lbl); sub(/[ ]*[,}].*/, "", lbl); gsub(/^"|"$/,"",lbl)
        st=line;  sub(/.*[,{][ ]*status:[ ]*/, "", st); sub(/[ ]*[,}].*/, "", st); gsub(/["{} ]/,"",st)
        ph=""                                                     # phase is optional (additive)
        if (match(line, /[,{][ ]*phase:[ ]*[^,}]*/)) { ph=substr(line,RSTART,RLENGTH); sub(/.*phase:[ ]*/,"",ph); sub(/[ ]+$/,"",ph); gsub(/^"|"$/,"",ph) }
        if (st=="") st="open"
        print n "|" lbl "|" st "|" ph; have=0; next
      }
      if (line ~ /^[ ]+-[ ]/) {                                  # ── block style: new list item
        flush(); have=1
        rest=line; sub(/^[ ]+-[ ]*/,"",rest)                     # may carry an inline field, e.g. "- n: 1"
        if (rest ~ /^n:/)      n=field(rest,"n")
        else if (rest ~ /^key:/) {}                              # key unused for rendering
        else if (rest ~ /^label:/)  lbl=field(rest,"label")
        else if (rest ~ /^status:/) st=field(rest,"status")
        else if (rest ~ /^phase:/)  ph=field(rest,"phase")
        next
      }
      if (have && line ~ /^[ ]+[A-Za-z_]+:/) {                   # ── block style: continuation field
        if (line ~ /^[ ]+n:/)        n=field(line,"n")
        else if (line ~ /^[ ]+label:/)  lbl=field(line,"label")
        else if (line ~ /^[ ]+status:/) st=field(line,"status")
        else if (line ~ /^[ ]+phase:/)  ph=field(line,"phase")
        next
      }
    }
    END { flush() }
  ' "$f"
}

# humain_total <yaml> → the breadcrumb denominator (workflow.total, or count of integer steps).
humain_total() {
  local f="$1" t
  t=$(humain_workflow_field "$f" total)
  if [[ -n "$t" && "$t" =~ ^[0-9]+$ ]]; then echo "$t"; return; fi
  humain_steps "$f" | awk -F'|' '$1 ~ /^[0-9]+$/ {n=$1} END{print n+0}'
}

# humain_current_n <yaml> → the `n` of the step whose status is `current` (e.g. "3" or "19a").
humain_current_n() {
  humain_steps "$1" | awk -F'|' '$3=="current"{print $1; exit}'
}

# humain_current_label <yaml> → the label of the current step.
humain_current_label() {
  humain_steps "$1" | awk -F'|' '$3=="current"{print $2; exit}'
}

# humain_cs_field <yaml> <name|phase|number> → read a field from the current_step block.
# Tolerant of block style ("current_step:\n  name: …") AND flow style
# ("current_step: { name: …, phase: … }"), and of quoted OR unquoted values (issue #15).
humain_cs_field() {
  awk -v key="$2" '
    /^current_step:/ {
      if ($0 ~ /^current_step:[ ]*\{/) {                     # flow style on one line
        line=$0
        if (match(line, key ":[ ]*\"[^\"]*\"")) { v=substr(line,RSTART,RLENGTH); sub(key ":[ ]*\"","",v); sub(/"$/,"",v); print v; exit }
        if (match(line, key ":[ ]*[^,}]+"))     { v=substr(line,RSTART,RLENGTH); sub(key ":[ ]*","",v); sub(/[ ]+$/,"",v); gsub(/^"|"$/,"",v); print v; exit }
        exit
      }
      f=1; next                                              # block style follows
    }
    f && /^[^ ]/ { exit }                                    # left the current_step block
    f && $0 ~ "^[ ]+" key ":" {
      v=$0; sub("^[ ]+" key ":[ ]*","",v); sub(/[ ]+#.*/,"",v); sub(/[ ]*$/,"",v); gsub(/^"|"$/,"",v); print v; exit
    }
  ' "$1"
}

# ── Change-activation + branch reconciliation (issue #12) ─────────────────────────────────────

# humain_change_active <yaml> → exit 0 if a change is active (file has current_step or workflow).
humain_change_active() {
  local f="$1"
  [[ -f "$f" ]] || return 1
  # A merged change is done, not active — a stale merged file left on the branch
  # (e.g. inherited on main) must not keep satisfying the session gate. Force
  # re-intake so the next change goes through the front door (issue #19).
  [[ "$(humain_scalar "$f" status)" == "merged" ]] && return 1
  grep -q "^current_step:" "$f" 2>/dev/null || humain_has_workflow "$f"
}

# humain_scalar <yaml> <field> → top-level scalar (e.g. change_id, expected_branch, tier).
humain_scalar() {
  awk -v k="$2" '$0 ~ "^" k ":" { sub("^" k ":[ ]*","",$0); gsub(/^"|"$/,"",$0); print; exit }' "$1"
}

# humain_branch_reconcile <yaml> <current_branch> → echoes one of:
#   noactive       — no change is active
#   match          — branch agrees with the active change
#   unverifiable    — non-issue/* branch with no expected_branch to check against (soft)
#   mismatch       — branch disagrees with the active change (hard)
# Rules: prefer an explicit `expected_branch`; else derive the issue number from `issue/N-*`
# and compare to change_id's number; else treat as unverifiable (don't nag deliberate branches).
humain_branch_reconcile() {
  local f="$1" branch="$2" expected change_id branch_issue yaml_issue
  humain_change_active "$f" || { echo "noactive"; return; }
  expected=$(humain_scalar "$f" expected_branch)
  if [[ -n "$expected" ]]; then
    [[ "$branch" == "$expected" ]] && echo "match" || echo "mismatch"
    return
  fi
  branch_issue=$(echo "$branch" | sed -n 's|issue/\([0-9][0-9]*\)-.*|\1|p')
  if [[ -n "$branch_issue" ]]; then
    change_id=$(humain_scalar "$f" change_id)
    yaml_issue=$(echo "$change_id" | sed -n 's|.*[^0-9]\([0-9][0-9]*\)$|\1|p')
    [[ -n "$yaml_issue" && "$branch_issue" == "$yaml_issue" ]] && echo "match" || echo "mismatch"
    return
  fi
  echo "unverifiable"
}

# humain_intake_directive — the mandatory session-start intake instruction. Emitted (to stdout,
# which Claude Code injects as context) by both the SessionStart hook (humain-gate.sh) and the
# UserPromptSubmit hook (welcome.sh) whenever no change is active for the current branch.
humain_intake_directive() {
  cat <<'DIRECTIVE'
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  ⛔ HumAIn — NO ACTIVE CHANGE FOR THIS BRANCH

  This is a HumAIn-enabled project. Before any real work (writing code, editing
  files) you MUST take the user through change intake. Intake itself is a normal
  conversation — talking through the work and creating an issue is expected and
  encouraged, not blocked:

    1. If the user has no issue yet, chat to shape the work, then create one
       (gh issue create, /humain:pm-add-feature, or /humain:pm-report-bug). If they
       already have an issue, help them choose it.
    2. Determine the right HumAIn workflow for it (development / brownfield /
       migration / prd) by reading the issue and confirming with the user.
    3. Show the full ordered step plan for that workflow.
    4. Write + commit + push .humain/current-change.yaml, then follow the breadcrumb.

  Run  /humain:dev-start-change  to do all of this. You may freely discuss and create
  the issue first — just don't start editing files until a change is active.
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
DIRECTIVE
}

# humain_render_trail <yaml> [color] [current_name]
#   Render the windowed step trail (3 back + current + 3 ahead), numberless, e.g.:
#     … ✓Conv ✓Rvw1 ✓Rvw2 ▶ Architect Code Review ·Rerun ·Recncl ·QAVfy …
#   Position is carried by order + the ▶ glyph — no global step numbers (Phase 2).
#   The current step is expanded to its full name when `current_name` (3rd arg) is given;
#   neighbours stay as short labels. Pass "color" (2nd arg) to wrap the current step green.
#   Glyphs: done ✓ · current ▶ · everything else (open/skipped/…) ·
humain_render_trail() {
  local f="$1" color="${2:-}" cur_name="${3:-}"
  humain_steps "$f" | awk -F'|' -v color="$color" -v curname="$cur_name" '
    BEGIN { GRN="\033[32m"; RST="\033[0m" }
    { n[NR]=$1; lbl[NR]=$2; st[NR]=$3; if ($3=="current") cur=NR }
    END {
      total=NR
      if (cur==0) cur=1
      ws=cur-3; if (ws<1) ws=1
      we=cur+3; if (we>total) we=total
      out=""
      if (ws>1) out="… "
      for (i=ws; i<=we; i++) {
        glyph="·"
        if (st[i]=="done") glyph="✓"
        else if (st[i]=="current") glyph="▶"
        if (st[i]=="current") {
          disp=(curname!="") ? curname : lbl[i]
          seg=glyph " " disp                    # current: glyph + space + full name
        } else seg=glyph lbl[i]                  # neighbour: glyph + short label, no number
        if (st[i]=="current" && color=="color") seg=GRN seg RST
        out=out seg " "
      }
      if (we<total) out=out "…"
      printf "%s", out
    }
  '
}

# humain_render_ribbon <yaml> → the phase ribbon (Phase 2), e.g.:
#     Requirements ✓  Design ✓  Build ◐  Verify ·  Assess ·  Ship ·  Post-Ship ·
#   Computed from the steps' per-step `phase` + `status`: a phase is ✓ when all its steps are
#   done, ◐ when it holds the current step (or is partly done), · when untouched. The ribbon
#   only changes when a *phase* is added/removed — never on a step renumber.
#   Back-compat: a change file whose steps carry no `phase` falls back to the lone
#   current_step.phase ("<phase> ◐"), so old files still render something sensible.
humain_render_ribbon() {
  local f="$1" out
  out=$(humain_steps "$f" | awk -F'|' '
    {
      ph=$4; if (ph=="") next
      st=$3
      if (!(ph in seen)) { seen[ph]=1; order[++np]=ph }
      cnt[ph]++
      if (st=="done") ndone[ph]++
      if (st=="current") cur[ph]=1
    }
    END {
      if (np==0) exit 0
      sep=""
      for (i=1;i<=np;i++) {
        p=order[i]
        if (cur[p])                 g="◐"
        else if (ndone[p]==cnt[p])  g="✓"
        else if (ndone[p]>0)        g="◐"
        else                        g="·"
        printf "%s%s %s", sep, p, g; sep="  "
      }
    }
  ')
  if [[ -n "$out" ]]; then printf "%s" "$out"; return; fi
  local cp; cp=$(humain_cs_field "$f" phase)
  [[ -n "$cp" ]] && printf "%s ◐" "$cp"
}
