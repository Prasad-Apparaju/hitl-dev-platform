#!/usr/bin/env bash
# Stop hook: generate a HumAIn session summary when Claude Code finishes a session.
# Lists artifacts changed, evidence collected, and missing evidence.

[[ -d ".humain" ]] || exit 0  # not a HumAIn project — skip silently

set -euo pipefail

# Resolve a working Python interpreter (Windows-safe; see issue #14). $HUMAIN_PY is set by the hook
# wrapper; otherwise probe. No usable Python → skip (summary is best-effort).
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"; source "$SCRIPT_DIR/_steps.sh"
PY=$(humain_python) || exit 0

CONTEXT_FILE=".humain/current-change.yaml"
if [[ ! -f "$CONTEXT_FILE" ]]; then
  exit 0  # no active change — nothing to summarize
fi

CHANGE_ID=$(grep "^change_id:" "$CONTEXT_FILE" | awk '{print $2}' | tr -d '"' 2>/dev/null || echo "unknown")
STATUS=$(grep "^status:" "$CONTEXT_FILE" | awk '{print $2}' | tr -d '"' 2>/dev/null || echo "unknown")
TIER=$(grep "^tier:" "$CONTEXT_FILE" | awk '{print $2}' | tr -d '"' 2>/dev/null || echo "unknown")

# Get changed files from git
CHANGED_FILES=$(git diff --name-only HEAD 2>/dev/null || echo "")
STAGED_FILES=$(git diff --name-only --cached 2>/dev/null || echo "")
ALL_CHANGED=$(printf '%s\n%s\n' "$CHANGED_FILES" "$STAGED_FILES" | sort -u | grep -v '^$' || echo "")

# Get required evidence from context file
REQUIRED_EVIDENCE=$("$PY" - << 'PYEOF'
import yaml
try:
    with open(".humain/current-change.yaml") as f:
        data = yaml.safe_load(f)
    ev = data.get("required_evidence", [])
    print("\n".join(ev) if ev else "none specified")
except Exception:
    print("error reading context file")
PYEOF
)

SUMMARY_DIR="docs/session-logs"
mkdir -p "$SUMMARY_DIR"

# Safety net: ensure session logs are gitignored — idempotent, adds entry only if missing
if ! grep -q "docs/session-logs" .gitignore 2>/dev/null; then
  printf '\n# HumAIn session logs — operational artifacts, not product code\ndocs/session-logs/\n' >> .gitignore
fi
TIMESTAMP=$(date +"%Y-%m-%d-%H%M%S")
SUMMARY_FILE="$SUMMARY_DIR/humain-session-${CHANGE_ID}-${TIMESTAMP}.md"

cat > "$SUMMARY_FILE" << SUMMARY
# HumAIn Session Summary

- **Change:** $CHANGE_ID
- **Tier:** $TIER
- **Status at session end:** $STATUS
- **Timestamp:** $(date -u +"%Y-%m-%dT%H:%M:%SZ")

## Files Changed This Session

$(if [[ -n "$ALL_CHANGED" ]]; then echo "$ALL_CHANGED" | sed 's/^/- /'; else echo "_No tracked changes detected._"; fi)

## Required Evidence Status

$(echo "$REQUIRED_EVIDENCE" | sed 's/^/- [ ] /')

## Next Steps

Review the evidence checklist above and ensure all required items are complete before architect code review (step 19a).

Run \`/humain:check-conventions\` to verify code quality before architect code review.

SUMMARY

echo "" >&2
echo "HumAIn Session Summary written to: $SUMMARY_FILE" >&2

exit 0
