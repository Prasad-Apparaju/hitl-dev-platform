# ai/claude/

**Claude Code slash command prompts** — the main AI runtime for the HumAIn workflow.

Each subdirectory is one slash command. The `SKILL.md` file inside it is the prompt Claude executes when you type that command. Skills have a frontmatter header (`name`, `description`, `argument-hint`) that the Claude Code plugin reads to register the command.

| Namespace | Commands |
|-----------|----------|
| *(root)* | `/humain:dev-practices`, `/humain:dev-tdd`, `/humain:dev-apply-change`, `/humain:dev-generate-docs`, `/humain:dev-check-conventions`, `/humain:dev-impact-brief`, `/humain:dev-conclude`, `/humain:dev-review-lld-adherence`, `/humain:dev-review-security`, `/humain:dev-update`, `/humain:ta-approve` |
| `/humain:dev-start-*` | `/humain:dev-start-from-prd`, `/humain:dev-start-brownfield`, `/humain:dev-start-migration` |
| `/humain:architect-` | `design-system`, `design-feature`, `review-code` |
| `/humain:pm-` | `add-feature`, `design-feature`, `prioritize`, `report-bug`, + 4 more |
| `/humain:qa-` | `plan-tests`, `review-tests`, `verify-quality`, `report-defect` |
| `/humain:ops-` | `build`, `deploy`, `apply-iac`, `backup-database`, `migrate-database`, + 6 more |
| `/humain:migrate-` | `review-external-docs` |

To customize a command, edit its `SKILL.md`. Note: `agents/`, `commands/`, and `hooks/` are subdirectories inside `ai/claude/` — they are part of the same AI runtime. Changes take effect on the next Claude Code session.
See [docs/customization-guide.md](../../docs/customization-guide.md) for the full command-to-file map.
