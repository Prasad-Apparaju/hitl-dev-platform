---
description: Onboard an existing codebase into the HumAIn process. Generates a documentation baseline from existing code, seeds the test and incident registries, and prepares for docs-first development going forward.
argument-hint: "[optional: path to source root or description of the codebase]"
disable-model-invocation: true
---

# Onboard an Existing Codebase

Bringing an existing codebase into HumAIn AI-Driven Development. Work through these steps in order — pause after each and wait for confirmation before proceeding.

**Quick sanity check:** If this is a brand-new project with no source code, use `/humain:dev-start-from-prd` instead. If you are migrating from one system to another (not just onboarding what exists), use `/humain:dev-start-migration`.

---

## Step 0 — Wire up HumAIn hooks (once per project)

Check whether `.humain/hooks/` already exists.

**If it does — hooks are already wired. Skip sub-steps 1–3, but still run sub-steps 4–5** (gitignore and ADR stubs are idempotent and must always be present):

1. Find the plugin root (needed for the ADR copy):
   ```bash
   python3 -c "
   import json, os, sys
   try:
       d = json.load(open(os.path.expanduser('~/.claude/plugins/installed_plugins.json')))
       for inst in d.get('plugins', {}).get('humain@humain', []):
           p = inst.get('installPath', '')
           if os.path.isfile(os.path.join(p, '.claude-plugin/plugin.json')):
               print(p); sys.exit(0)
   except: pass
   try:
       d = json.load(open(os.path.expanduser('~/.claude/settings.json')))
       for p in d.get('plugins', []):
           path = p if isinstance(p, str) else p.get('path', '')
           if os.path.isfile(os.path.join(path, '.claude-plugin/plugin.json')):
               print(path); sys.exit(0)
   except: pass
   print('NOT_FOUND')
   "
   ```
2. Run sub-steps 4 and 5 below (gitignore + ADR stubs), then say "Hooks already wired — skipped hook creation, ensured ADR stubs present." and proceed to Step 1.

**If it does not exist — run all sub-steps:**

1. Find the HumAIn plugin path:
   ```bash
   python3 -c "
   import json, os, sys
   try:
       d = json.load(open(os.path.expanduser('~/.claude/plugins/installed_plugins.json')))
       for inst in d.get('plugins', {}).get('humain@humain', []):
           p = inst.get('installPath', '')
           if os.path.isfile(os.path.join(p, '.claude-plugin/plugin.json')):
               print(p); sys.exit(0)
   except: pass
   try:
       d = json.load(open(os.path.expanduser('~/.claude/settings.json')))
       for p in d.get('plugins', []):
           path = p if isinstance(p, str) else p.get('path', '')
           if os.path.isfile(os.path.join(path, '.claude-plugin/plugin.json')):
               print(path); sys.exit(0)
   except: pass
   print('NOT_FOUND')
   "
   ```
   If the result is `NOT_FOUND`, stop and say: "The HumAIn plugin was not found in your Claude Code settings. Install it with: `claude plugin marketplace add pappar/humain-claude-plugin && claude plugin install humain@humain`"

2. Create `.humain/hooks/` and write a wrapper for each of these eight hooks: `welcome`, `humain-gate`, `check-humain-context`, `check-domain-boundary`, `rebuild-graph`, `write-session-summary`, `sync-step-to-issue`, `statusline-humain`. (The shared `_steps.sh` library is sourced by the renderers from the plugin directly — it does not need a wrapper.) Each wrapper discovers the plugin path at runtime — survives plugin updates, reinstalls, and version bumps:
   ```bash
   #!/usr/bin/env bash
   PLUGIN_ROOT=$(python3 -c "
   import json,os,sys
   try:
     d=json.load(open(os.path.expanduser('~/.claude/plugins/installed_plugins.json')))
     for inst in d.get('plugins',{}).get('humain@humain',[]):
       p=inst.get('installPath','')
       if os.path.isfile(os.path.join(p,'.claude-plugin/plugin.json')):
         print(p);sys.exit(0)
   except:pass
   try:
     d=json.load(open(os.path.expanduser('~/.claude/settings.json')))
     for p in d.get('plugins',[]):
       path=p if isinstance(p,str) else p.get('path','')
       if os.path.isfile(os.path.join(path,'.claude-plugin/plugin.json')):
         print(path);sys.exit(0)
   except:pass
   " 2>/dev/null)
   [[ -z "$PLUGIN_ROOT" ]] && exit 0
   exec bash "$PLUGIN_ROOT/hooks/<name>.sh" "$@"
   ```
   Replace `<name>` with the hook name for each file. Run `chmod 750` on each file.

3. Create `.claude/settings.json` only if it does not already exist:
   ```json
   {
     "statusLine": "bash \"$CLAUDE_PROJECT_DIR/.humain/hooks/statusline-humain.sh\"",
     "hooks": {
       "SessionStart": [{ "hooks": [{ "type": "command", "command": "bash \"$CLAUDE_PROJECT_DIR/.humain/hooks/humain-gate.sh\"" }] }],
       "UserPromptSubmit": [{ "hooks": [{ "type": "command", "command": "bash \"$CLAUDE_PROJECT_DIR/.humain/hooks/welcome.sh\"" }] }],
       "PreToolUse": [{ "matcher": "Edit|Write", "hooks": [{ "type": "command", "command": "bash \"$CLAUDE_PROJECT_DIR/.humain/hooks/check-humain-context.sh\"" }] }],
       "PostToolUse": [{ "matcher": "Edit|Write", "hooks": [
         { "type": "command", "command": "bash \"$CLAUDE_PROJECT_DIR/.humain/hooks/check-domain-boundary.sh\"" },
         { "type": "command", "command": "bash \"$CLAUDE_PROJECT_DIR/.humain/hooks/rebuild-graph.sh\"" },
         { "type": "command", "command": "bash \"$CLAUDE_PROJECT_DIR/.humain/hooks/sync-step-to-issue.sh\"" }
       ]}],
       "Stop": [{ "hooks": [{ "type": "command", "command": "bash \"$CLAUDE_PROJECT_DIR/.humain/hooks/write-session-summary.sh\"" }] }]
     }
   }
   ```

4. Update `.gitignore` so session logs don't end up in the product repo — add the entry if not already present:
   ```bash
   grep -q "docs/session-logs" .gitignore 2>/dev/null || printf '\n# HumAIn session logs — operational artifacts, not product code\ndocs/session-logs/\n' >> .gitignore
   ```

5. Copy default ADR stubs into `docs/02-design/technical/adrs/` — skip any file that already exists (never overwrite existing ADRs):
   ```bash
   mkdir -p docs/02-design/technical/adrs
   for f in "$PLUGIN_ROOT/shared/templates"/adr-000*.md; do
     dest="docs/02-design/technical/adrs/$(basename "$f")"
     [[ -f "$dest" ]] || cp "$f" "$dest"
   done
   ```
   Then fill in today's date in `adr-0001-humain-adoption.md` and `adr-0002-documentation-first.md` (replace `[fill in: project start date]` with today's ISO date).

6. Say: "Hooks wired. `.humain/hooks/`, `.claude/settings.json`, `.gitignore`, and 8 baseline ADRs created in `docs/02-design/technical/adrs/`. **Restart Claude Code now** so the hooks load, then re-run this command to continue setup."

---

## Step 1 — Map the codebase

**Write `.humain/current-change.yaml` now** (enables breadcrumbs immediately) with the embedded
`brownfield` workflow block — copied from the catalog at `ai/shared/workflows.yaml`:
```yaml
schema_version: "2.0"
change_id: brownfield-setup
tier: 0
status: planning
workflow:
  id: brownfield
  total: 11
  steps:
    - { n: 1,  key: map_code,        label: "MapCode",    phase: "Brownfield Setup", status: current }
    - { n: 2,  key: claude_md,       label: "CLAUDE.md",  phase: "Brownfield Setup", status: open }
    - { n: 3,  key: manifest,        label: "Manifest",   phase: "Brownfield Setup", status: open }
    - { n: 4,  key: arch_review,     label: "ArchRvw",    phase: "Brownfield Setup", status: open }
    - { n: 5,  key: verify_pipeline, label: "Pipeline",   phase: "Brownfield Setup", status: open }
    - { n: 6,  key: observability,   label: "Observ",     phase: "Brownfield Setup", status: open }
    - { n: 7,  key: priority_docs,   label: "Docs",       phase: "Brownfield Setup", status: open }
    - { n: 8,  key: seed_registries, label: "Registries", phase: "Brownfield Setup", status: open }
    - { n: 9,  key: graphify,        label: "Graphify",   phase: "Brownfield Setup", status: open }
    - { n: 10, key: create_issue,    label: "Issue",      phase: "Brownfield Setup", status: open }
    - { n: 11, key: confirm_ready,   label: "Ready",      phase: "Brownfield Setup", status: open }
current_step:
  number: 1
  name: "Map codebase"
  phase: "Brownfield Setup"
```

> **Breadcrumb advancement:** at the start of each step below, edit `.humain/current-change.yaml`
> to set the previous step's `status: done` and the current step's `status: current`, and update
> `current_step` to match.

List the top-level directories and identify source code locations.
- Ask: "Are these the right source directories? Anything to exclude?"
- Confirm the language and framework.

---

## Step 2 — Customize CLAUDE.md

Update `.humain/current-change.yaml` — set `current_step`:
```yaml
  number: 2
  name: "Customize CLAUDE.md"
  phase: "Brownfield Setup"
```

If `CLAUDE.md` has template placeholders (`{{coding_standards}}`, `{{#conventions}}`):
- Ask: "What are this project's naming conventions, test framework, and any standards AI should follow?"
- Fill in the placeholders based on their answers and the observed codebase patterns.
- Show a diff of what changed.
- Ask: "Does this look right? Any other conventions to add?"

If `CLAUDE.md` already has real content, say: "`CLAUDE.md` looks customized — skipping." and move on.

---

## Step 3 — Generate the system manifest baseline

Update `.humain/current-change.yaml` — set `current_step`:
```yaml
  number: 3
  name: "Generate manifest"
  phase: "Brownfield Setup"
```

If `docs/system-manifest.yaml` is missing or template-only:
- Run: `python tools/generate-manifest/generator.py --source [confirmed source dirs] --output docs/system-manifest.yaml`
- If the generator is unavailable, say so and ask: "Describe your main services and domains — I'll create the manifest manually."
- After generating, show the domain list and ask: "Review these domains. What should be added, removed, or renamed?"
- Incorporate feedback and update the manifest.

If a real manifest already exists, read it, summarize the domains, and ask: "Is this manifest still accurate? Anything outdated?"

**Install the manifest drift checker.** The manifest is only load-bearing if something keeps it honest. Resolve the plugin root once (reused in later steps), then copy the checker into the repo so `/humain:dev-check-conventions` and the `ci/workflows/*.yml` templates (which reference it by repo path) can run it:

```bash
PLUGIN_ROOT=$(python3 -c "import json,os,sys;d=json.load(open(os.path.expanduser('~/.claude/plugins/installed_plugins.json')));[print(i['installPath']) or sys.exit(0) for i in d.get('plugins',{}).get('humain@humain',[]) if os.path.isfile(os.path.join(i.get('installPath',''),'.claude-plugin/plugin.json'))]" 2>/dev/null)
if [[ -n "$PLUGIN_ROOT" && -f "$PLUGIN_ROOT/shared/ci/manifest-drift/check_manifest_drift.py" ]]; then
  mkdir -p ci/manifest-drift
  [[ ! -f ci/manifest-drift/check_manifest_drift.py ]] && cp "$PLUGIN_ROOT/shared/ci/manifest-drift/"*.py ci/manifest-drift/
fi
```

The checker derives its scan roots from the manifest's listed files, so it needs no per-project configuration. If `$PLUGIN_ROOT` is empty, skip; `/humain:dev-check-conventions` reports the checker as absent rather than passing.

---

## Step 4 — Review existing architecture

Update `.humain/current-change.yaml` — set `current_step`:
```yaml
  number: 4
  name: "Arch review"
  phase: "Brownfield Setup"
```

Run `/humain:architect-review-existing` to reconstruct the architectural decisions already in the codebase, interview the architect to confirm rationale and constraints, and document them as real ADRs before any incremental work begins.

This step produces:
- A tech stack summary
- ADR-0005+ for significant existing decisions (framework, data, auth, API style, deployment, test strategy)
- A list of architectural concerns that affect HumAIn compliance or first-change risk

Do not proceed to Step 7 until the architect has confirmed the ADRs are accurate.

---

## Step 5 — Verify build and deployment pipeline

Update `.humain/current-change.yaml` — set `current_step`:
```yaml
  number: 5
  name: "Verify pipeline"
  phase: "Brownfield Setup"
```

The deployment view generated in Step 4 (Phase 4c of `/humain:architect-review-existing`) describes the CI/CD pipeline. This step confirms it actually works before feature development begins.

**1. Identify the CI/CD system:**

Check which CI/CD configuration files exist:

| File | System |
|---|---|
| `.github/workflows/*.yml` | GitHub Actions |
| `Jenkinsfile` | Jenkins |
| `.gitlab-ci.yml` | GitLab CI |
| `.circleci/config.yml` | CircleCI |
| `.buildkite/pipeline.yml` | Buildkite |

If none found: skip to "Pipeline missing" below.

**2. Verify the build:**

Run the project's build command (infer from the tech stack confirmed in Step 2 — `npm run build`, `mvn package`, `go build ./...`, `./gradlew build`, etc.).

- ✅ Build passes → continue
- 🔴 Build fails → record the error and say: "Build is broken — fix this before feature work begins. Run `/humain:ops-build` for a structured diagnosis."

**3. Verify the deployment path:**

Check whether the CI/CD config includes:
- A job that deploys to at least one non-production environment (staging, dev, test)
- A job or manual gate for production deploy

The 31-step workflow (`/humain:dev-practices`) gates every PR on a passing staging deploy — if no staging job exists, that gate cannot function.

- ✅ Staging deploy job exists → proceed
- 🟡 No staging deploy job → note it: "The HumAIn staging gate will need a manual workaround until a staging deploy job is added."
- 🔴 No deploy jobs at all → treat same as pipeline missing below

**Pipeline missing or broken:**

If no CI/CD config exists, or the build fails and cannot be quickly fixed, say:

> "No working build pipeline found. This is a 🔴 concern — the 31-step workflow requires a passing build and a staging deploy path before a PR can be closed. Options:
> - Scaffold a CI/CD config now: describe your hosting target (GitHub Actions → AWS/GCP/Azure/Railway/Fly.io) and I'll generate a starter pipeline
> - Set it up manually and re-run this step when ready
> - Proceed and accept that the build and deploy steps of the 31-step workflow will need manual execution until the pipeline exists"

If they want a scaffold, generate a minimal CI/CD config (build → test → deploy-to-staging) using the tech stack from Step 2 and the deployment target from the deployment view. Do not include a production deploy job without an explicit approval gate.

**Persist the verdicts (required):** copy `"$PLUGIN_ROOT/shared/templates/platform-readiness-template.yaml"`
to `docs/04-operations/platform-readiness.yaml` if missing, set `project_kind: brownfield`,
and record this step's verdicts there: `E1` (build reproducible), `E3` (staging deploy from
CI), `D1` (suites run in CI and can fail) — evidence rules are in the template header. The
register feeds `/humain:ops-plan-platform` (Step 11) and the production-deploy gate; a verdict
not written here does not exist.

---

## Step 6 — Set up observability

Update `.humain/current-change.yaml` — set `current_step`:
```yaml
  number: 6
  name: "Set up observability"
  phase: "Brownfield Setup"
```

HumAIn requires two observability layers: **application observability** (logs, metrics, tracing, alerting — so production failures are visible and pages fire) and **agentic observability** (session logs, token cost — so AI-assisted development costs and decisions are tracked). Both must be in place before the first Tier 2 change is deployed.

**1. Survey existing application observability:**

Check for evidence of each signal type:

| Signal | Where to look |
|---|---|
| Structured logs | Logger imports, `log4j.properties`, `logging.yaml`, Logback config, sidecar containers in k8s |
| Metrics | Prometheus scrape config, Datadog/CloudWatch agent config, `micrometer`/`actuator`, metrics libraries in package files |
| Distributed tracing | OpenTelemetry config, Jaeger/Zipkin clients, Datadog APM, trace headers in middleware |
| Error tracking | Sentry SDK, Rollbar client, error reporting middleware |
| Dashboards | `grafana/`, `datadog/monitors/`, CloudWatch dashboard JSON |
| Alerting | `grafana/alerts/`, `datadog/monitors/`, CloudWatch alarms, PagerDuty config |

Record what is present, what is absent, and which tool is in use for each signal type.

**2. Set up agentic observability:**

| Signal | Check | Action if missing |
|---|---|---|
| Session logs | `docs/session-logs/` is in `.gitignore` and `write-session-summary.sh` hook is wired | Step 0 handles this — flag if absent |
| Token cost registry | `docs/04-operations/token-cost-registry.yaml` exists | Copy from plugin template (see below) |

Create the token cost registry if it does not exist:
```bash
mkdir -p docs/04-operations
PLUGIN_ROOT=$(python3 -c "
import json,os,sys
try:
  d=json.load(open(os.path.expanduser('~/.claude/plugins/installed_plugins.json')))
  for inst in d.get('plugins',{}).get('humain@humain',[]):
    p=inst.get('installPath','')
    if os.path.isfile(os.path.join(p,'.claude-plugin/plugin.json')):
      print(p);sys.exit(0)
except:pass
try:
  d=json.load(open(os.path.expanduser('~/.claude/settings.json')))
  for p in d.get('plugins',[]):
    path=p if isinstance(p,str) else p.get('path','')
    if os.path.isfile(os.path.join(path,'.claude-plugin/plugin.json')):
      print(path);sys.exit(0)
except:pass
" 2>/dev/null)
[[ ! -f docs/04-operations/token-cost-registry.yaml ]] && \
  cp "$PLUGIN_ROOT/shared/templates/token-cost-registry-template.yaml" \
     docs/04-operations/token-cost-registry.yaml
```

**3. Fill in ADR-0005:**

`docs/02-design/technical/adrs/adr-0005-observability-strategy.md` was copied in Step 0. Open it and fill in the tools found in step 1. Ask the architect:
> "Are the observability tools listed in ADR-0005 correct? Any planned changes? Who owns on-call for production incidents in each domain?"

**4. Flag gaps:**

| Gap | Severity | Action |
|---|---|---|
| No structured logging | 🔴 | Required before first Tier 2 deploy — add a structured logging library for the tech stack |
| No metrics or dashboards | 🟡 | Run `/humain:ops-setup-observability` per change to instrument go/no-go criteria |
| No alerting or on-call routing | 🟡 | Must be configured before first production deploy — required by `/humain:ops-deploy` |
| No error tracking | 🟢 | Recommended — Sentry free tier covers most projects |
| No distributed tracing | 🟢 | Optional for monoliths; required for microservices with cross-service calls |
| Token cost registry missing | 🟡 | Created above — update at Step 31 of every change |

**5. Persist the survey (required):** record `F1` in the readiness register (from Step 5):
`verified` with instrument names as evidence, or `gap` at the worst open row's severity with
the open rows listed. An unrecorded gap is invisible to the roadmap and the deploy gate.

---

## Step 7 — Identify priority components for documentation

Update `.humain/current-change.yaml` — set `current_step`:
```yaml
  number: 7
  name: "Priority docs"
  phase: "Brownfield Setup"
```

Ask: "Which components are most critical and most likely to change in the near term? List up to three."

For each component:
- Say: "I'll generate an HLD and LLD for [component]. Run `/humain:dev-generate-docs` or I can do it now — which do you prefer?"
- If they want it now, run `/humain:dev-generate-docs` for that component.
- Note: this is incremental — you do not need to document everything before starting work.

---

## Step 8 — Seed the registries

Update `.humain/current-change.yaml` — set `current_step`:
```yaml
  number: 8
  name: "Seed registries"
  phase: "Brownfield Setup"
```

The 31-step workflow queries these two registries at multiple points. They must exist before `/humain:dev-practices` is run for the first time.

**Test registry** (`docs/03-engineering/testing/test-registry.yaml`):
- Ask: "Do you have existing tests? If so, I'll create a registry stub from your test files."
- If yes: scan `tests/`, `spec/`, or equivalent; generate one entry per test file with `domain` and `path`. Leave `risk` and `covers` as DRAFT.
- If no: create an empty stub.

**Incident registry** (`docs/04-operations/incident-registry.yaml`):
- Ask: "What broke in production in the last 6 months? Describe each incident in one sentence."
- For each answer, add one entry with `description`, `domain` (best guess), and `date`.
- If they have nothing: create an empty stub and say: "You can add entries later — after each production incident, run `/humain:ops-incident`."

**Product baseline** (`docs/01-product/prd.md`): the PM and QA skills read the PRD for personas and requirements, so a brownfield project with no PRD leaves them nowhere to land. Initialize the PRD *shell*, not a retroactive spec of existing behaviour (that lives in the reverse-engineered technical docs), only personas and format so the next requirement has a home. If `docs/01-product/prd.md` is missing and `$PLUGIN_ROOT` (Step 3) is set, run `mkdir -p docs/01-product && cp "$PLUGIN_ROOT/shared/templates/prd-template.md" docs/01-product/prd.md`. Then ask "Who are the primary users of this system, and what does each need?" and fill §3 (Target Users and Personas); leave §5 (Functional Requirements) empty, noted "No requirements yet — added via `/humain:pm-add-feature`." Say: "Product baseline initialized; PM and QA skills are now active."

---

## Step 9 — Build Graphify knowledge graph (optional)

Update `.humain/current-change.yaml` — set `current_step`:
```yaml
  number: 9
  name: "Graphify"
  phase: "Brownfield Setup"
```

Graphify builds a queryable knowledge graph from your docs and code. HumAIn skills use it to look up domains, incidents, and test coverage without exhausting the context window.

Run `graphify --version` to check if it is installed.

**If installed:** run the per-project commands now:
```bash
graphify .              # build the graph from existing code and docs
graphify hook install   # auto-rebuild on every git commit
```

Then commit so teammates get it immediately:
```bash
echo "graphify-out/manifest.json" >> .gitignore
echo "graphify-out/cost.json" >> .gitignore
git add graphify-out/ .gitignore
git commit -m "chore: add graphify knowledge graph"
```

**If not installed:** say "Graphify not found — skipping. Install it when convenient with `uv tool install graphifyy && graphify claude install`, then run `graphify .` in this repo. HumAIn skills fall back gracefully without it. See `shared/graphify-setup.md`." and continue to Step 8.

---

## Step 10 — Create your first change issue

Update `.humain/current-change.yaml` — set `current_step`:
```yaml
  number: 10
  name: "Create issue"
  phase: "Brownfield Setup"
```

Ask: "What's the first change you want to make now that this project is onboarded?"
- Run: `gh issue create --title "[change description]" --body "First tracked change after HumAIn brownfield onboarding."`
- Show the issue URL.

---

## Step 11 — Confirm ready

Update `.humain/current-change.yaml` — set `current_step`:
```yaml
  number: 11
  name: "Confirm ready"
  phase: "Brownfield Setup"
```

Output this exactly:

---
**Brownfield baseline established.**

You are starting incrementally: manifest and priority component docs exist, registries are seeded.

**What this means for your first changes:**
- Treat AI output from steps 5, 10, and 14 as drafts — the docs are new and may not yet reflect actual behavior. Increase human review scrutiny until the docs have been corrected through real use.
- If `/humain:dev-practices` stops with "no LLD found" on an undocumented component, run `/humain:dev-generate-docs` for that component, then resume. This friction decreases naturally as each component gets its first doc pass through real use.

For every change going forward:
1. Create a GitHub issue — or use `/humain:pm-add-feature` / `/humain:pm-design-feature` to shape requirements first
2. Run `/humain:dev-practices` — the 31-step workflow starts here
3. Update HLD/LLD if the design changes
4. Code → tests → PR

**Next: the platform roadmap.** Steps 5-6 wrote the readiness register; changes can be
*made* now but *delivered to customers* only once it is green. Run
`/humain:ops-plan-platform roadmap` to turn the recorded gaps into phased GitHub issues (each
an ordinary HumAIn change). Tier 2+ **production** deploys stay blocked until delivery-ready.

---
