# ai/shared/templates/

**Document scaffolds used by AI skills** — skills read these and fill them in. Humans receive the completed output, not these raw files.

| Template | Used by |
|----------|---------|
| `prd-template.md` | `/humain:pm-add-feature`, `/humain:pm-design-feature` |
| `decision-packet-template.yaml` | `/humain:apply-change`, `/humain:architect-design-feature` |
| `incident-registry-template.yaml` | `/humain:dev-practices`, `/humain:impact-brief` |
| `test-registry-template.yaml` | `/humain:tdd`, `/humain:qa-plan-tests` |
| `test-strategy-template.md` | `/humain:qa-plan-tests` |
| `deployment-manifest-template.yaml` | `/humain:ops-deploy`, `/humain:ops-apply-iac` |
| `system-manifest-template.yaml` | `tools/scripts/init-project.sh` (copied to new product repos) |
| `issue-template.md` | `/humain:pm-report-bug`, `/humain:pm-add-feature` |
| `pull-request-template.md` | `/humain:conclude` |
| `*-template.md` (others) | `/humain:generate-docs`, `/architect:*` |

HLD, LLD, ADR, and CLAUDE.md templates live in `ai/claude/generate-docs/templates/` — co-located with the skill that uses them.
